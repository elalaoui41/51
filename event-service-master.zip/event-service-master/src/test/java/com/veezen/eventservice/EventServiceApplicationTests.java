package com.veezen.eventservice;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.context.TestPropertySource;

@SpringBootTest
@ComponentScan(basePackages = "com.veezen.eventservice.service")
@TestPropertySource(properties = "spring.mongodb.embedded.version=3.5.5")
class EventServiceApplicationTests {





//	@ParameterizedTest(name = "EventType: {0}")
//	void contextLoads(EventServiceFactory eventServiceFactory) {
//		eventServiceFactory.create(new IndividualEvent(
//				"sdfsdf", "dsfs",
//				LocalDateTime.now().minus(1, ChronoUnit.HOURS),
//				LocalDateTime.now().plus(1, ChronoUnit.HOURS),
//				"dssf", EventType.LOCAL,
//				new LocalMettingInfo("dsf",
//						"dsf",
//						"dsf",
//						45000),UUID.randomUUID(),
//				UUID.randomUUID())).subscribe(System.out::println);
//	}

}
