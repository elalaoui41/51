package com.veezen.eventservice.model.implementation;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.veezen.eventservice.model.VeeUser;
import com.veezen.eventservice.model.types.EventStatus;
import com.veezen.eventservice.model.types.EventLocationType;
import com.veezen.eventservice.model.api.Event;
import com.veezen.eventservice.model.api.MeetingInfo;
import com.veezen.eventservice.model.types.EventType;
import com.veezen.eventservice.model.types.NotificationType;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.lang.Nullable;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;



@Getter
@Setter
@Builder
@AllArgsConstructor
@Document(collection = "vee_individualEvents")
public class IndividualEvent extends Event {
    public static final String NAME = "IndividualEvent";
    @Id
    private String id;
    private String name;
    private String description;
    @Indexed
    private LocalDateTime startDate;

    @Transient
    private boolean joinable;
    @Indexed
    private LocalDateTime endDate;

    @Indexed
    private EventLocationType locationType;
    private Set<String> attachments;
    private Set<UUID> attendeesIds;
    private  Set<UUID> spheresIds;
    private Integer maxAttendees;
    @Transient
    private Set<VeeUser> attendees;
    @Transient
    private VeeUser orginizer;
    private EventType type;
    private UUID organizerId;
    private Integer duration;
    private MeetingInfo meetingInfo;
    private EventStatus status;
    private Double dailyDuration;
    private BillingInfo billingInfo;
    public IndividualEvent()
    {
        super();
    }
    public IndividualEvent(
            @Nullable @JsonProperty("name") String name,
            @Nullable @JsonProperty("description") String description,
            @Nullable @JsonProperty("startDate") LocalDateTime startDate,
            @Nullable @JsonProperty("duration") Integer duration,
            @Nullable @JsonProperty("locationType") EventLocationType locationType,
            @Nullable @JsonProperty("attachments") Set<String> attachments,
            @Nullable @JsonProperty("spheresIds") Set<UUID> spheresIds,
            @Nullable @JsonProperty("dailyDuration") Double dailyDuration,
            @Nullable @JsonProperty("meetingInfo") MeetingInfo meetingInfo,
            @Nullable @JsonProperty("attendeeId") UUID attendeeId,
            @Nullable @JsonProperty("organizerId") UUID organizerId
    ){
        super();
        this.name = name;
        this.description = description;
        this.dailyDuration =dailyDuration;
        this.meetingInfo = meetingInfo;
        this.startDate = startDate;
        this.spheresIds = spheresIds;
        this.attachments = attachments;
        this.duration = duration;
        this.joinable =false;
        this.type = EventType.INDIVIDUAL;
       if (duration != null && dailyDuration != null && startDate != null) {
           this.endDate = startDate.plusDays(duration)
                   .plusHours(dailyDuration.longValue())
                   .plusMinutes((long) (((dailyDuration - dailyDuration.longValue()) * 60)));
       }
        this.status = EventStatus.PENDING;
        this.locationType = locationType;
        this.attendeesIds = attendeeId != null ? Set.of(attendeeId): new HashSet<>();
        this.organizerId = organizerId;
        this.maxAttendees = 1;
        this.id = UUID.randomUUID().toString();

    }

    public IndividualEvent(EventRequest request) {
         this(request.getName(),
                request.getDescription(),
                request.getStartDate(),
                request.getDuration(),
                request.getLocationType(),
                request.getAttachments(),
                request.getSpheresIds(),
                request.getDailyDuration(),
                request.getMeetingInfo(),
                null,
                request.getOrganizerId());
    }


    @Override
    public boolean isJoinableBy(UUID id) {
        this.joinable = false;
        return false;
    }

    @Override
    public Notification generateNotification(NotificationType type) {
        return null;
    }

    public static IndividualEvent from(Event event){
        return IndividualEvent.builder()
                .name(event.getName())
                .description(event.getDescription())
                .startDate(event.getStartDate())
                .endDate(event.getEndDate())
                .type(event.getType())
                .locationType(event.getLocationType())
                .attendeesIds(event.getAttendeesIds())
                .organizerId(event.getOrganizerId())
                .spheresIds(event.getSpheresIds())
                .meetingInfo(event.getMeetingInfo())
                .dailyDuration(event.getDailyDuration())
                .id(UUID.randomUUID().toString())
                .status(event.getStatus())
                .build();
    }
}
