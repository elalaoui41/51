package com.veezen.eventservice.dao;

import com.veezen.eventservice.model.implementation.CollectiveOpenEvent;
import org.springframework.stereotype.Repository;

@Repository("CollectiveOpenEventRepository")
public interface CollectiveOpenEventRepository extends EventDao<CollectiveOpenEvent> {

}
