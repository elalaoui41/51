package com.veezen.eventservice.dao;

import com.veezen.eventservice.model.api.Event;
import com.veezen.eventservice.model.types.EventStatus;
import com.veezen.eventservice.model.types.EventType;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;
import java.util.UUID;

public interface EventDao<T extends Event> extends ReactiveMongoRepository<T, String > {
    @Query(value = " {$and: [" +
            " {$or:" +
            "[" +
            "{'attendeesIds': { $all: [?0] }} ," +
            "{'organizerId': ?0}" +
            "]}" +
            " , {$or:" +
            "[ {'startDate': " +
            "{ $gte: ?1 , $lte: ?2 }}" +
            ",{ 'endDate':" +
            " { $gte: ?1 , $lte: ?2 }}" +
            "]}]}"
            ,fields = "{'dailyDuration':  1}",
            count = true)
    Mono<Long> countAllByStartDateBetween(LocalDateTime start, LocalDateTime end);
    /* . < [ .  ]>*/
    @Query(value = " {$and: [" +
            " {$or:" +
            "[" +
            "{'attendeesIds': { $all: [?0] }} ," +
            "{'organizerId': ?0}" +
            "]}" +
            " , {$or:" +
            "[ {'startDate': " +
            "{ $gte: ?1 , $lte: ?2 }}" +
            ",{ 'endDate':" +
            " { $gte: ?1 , $lte: ?2 }}" +
            "]}]}"
            ,fields = "{'dailyDuration':  1}"
            ,count = true)
    Mono<Long> countAllMyEventInRange(
            UUID id,
            LocalDateTime start, LocalDateTime end);
    @Query(value = " {$and: [" +
            " {$or:" +
            "[" +
            "{'attendeesIds': { $all: [?0] }} ," +
            "{'organizerId': ?0}" +
            "]}" +
            " , {$or:" +
            "[ {'startDate': " +
            "{ $gte: ?1 , $lte: ?2 }}" +
            ",{ 'endDate':" +
            " { $gte: ?1 , $lte: ?2 }}" +
            "]}]}")
    Flux<? extends Event> findAllyMyActiveDailyDurationInRange(
            UUID id,
            LocalDateTime start, LocalDateTime end);
    @Query( value = " {$and:[ " +
            " { 'startDate': { $gte: ?0 , $lte: ?1 }}" +
            ",{ 'endDate': { $gte: ?0 , $lte: ?1 }}" +
            "]}")

    Flux<? extends Event> findAllDailyHoursInRange(
            LocalDateTime start, LocalDateTime end);

//            UUID id2,
//            UUID organizer2,
//            LocalDateTime start2, LocalDateTime end2);
    Mono<Long> countAllById(String id);

    Flux<? extends Event> findAllByStartDateBetween(LocalDateTime start, LocalDateTime end);
    @Query( value = " {$and: " +
            "[" +
            " {$or:" +
            "[{'attendeesIds': { $all: [?0] }} ,{'organizerId':  ?0}" +
            "]} " +
            ", { 'startDate': { $gte: ?1 , $lte: ?2 }}" +
            "]}")

    Flux<? extends Event> findAllByAttendeesIdsContainingOrOrganizerIdAndStartDateBetween(
            UUID id,
            LocalDateTime start, LocalDateTime end);

    @Query(value = " {$and: [" +
            "{'type': ?0}"+
            ",{'status': ?1}"+
            ",{'startDate': { $gte: ?2 , $lte: ?3 }}"+
            ",{'endDate': { $gte: ?2 , $lte: ?3 }}"+
            "]}")
    Flux<? extends Event> findAllByTypeAndStatusAndStartDateBetween(EventType type, EventStatus status,
                                                                    LocalDateTime start, LocalDateTime end);
}
