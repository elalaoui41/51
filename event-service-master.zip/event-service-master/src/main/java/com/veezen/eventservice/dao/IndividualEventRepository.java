package com.veezen.eventservice.dao;

import com.veezen.eventservice.model.api.Event;
import com.veezen.eventservice.model.implementation.IndividualEvent;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;
import java.util.UUID;

@Repository("IndividualEventRepository")
public interface IndividualEventRepository
        extends  EventDao<IndividualEvent> {

}
