package com.veezen.eventservice.model.implementation;

import com.veezen.eventservice.model.api.RemoteMettingInfo;
import lombok.*;

import java.util.HashMap;
import java.util.Map;



@Getter
@Setter
@NoArgsConstructor
public class JitsiMeettingInfo extends RemoteMettingInfo {
    public static final String NAME = "ZoomMeettingInfo";
    private String token;
    private String url;
    private String password;

    public JitsiMeettingInfo(String token, String url, String password)
    {
        super();
        this.token  = token;
        this.url = url;
        this.password = password;
        this.info = generateInfo();
    }
    @Override
    public Map<String, Object> generateInfo() {
        var map = new HashMap<String, Object>();
        map.put("token", this.getToken());
        map.put("url", this.getUrl());
        map.put("password", this.getPassword());
        return null;
    }


}
