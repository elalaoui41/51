package com.veezen.eventservice.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Builder
@Data
@AllArgsConstructor
public class Counts {
    private LocalDateTime date;
    private String month;
    private int year;
    private String day;
    private long count;

}
