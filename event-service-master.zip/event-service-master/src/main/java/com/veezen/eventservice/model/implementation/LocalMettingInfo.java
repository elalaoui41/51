package com.veezen.eventservice.model.implementation;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.veezen.eventservice.model.api.MeetingInfo;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.HashMap;
import java.util.Map;

@Data()
@NoArgsConstructor
public class LocalMettingInfo extends MeetingInfo {
    public static final String NAME = "LocalMettingInfo";
    private String street;
    private String city;
    private String country;
    private int postalCode;

    public LocalMettingInfo(@JsonProperty("street") String street,
                            @JsonProperty("city") String city,
                            @JsonProperty("country") String country,
                            @JsonProperty("postalCode") int postalCode
                            )
    {
        super();
        this.street = street;
        this.city = city;
        this.country = country;
        this.postalCode = postalCode;
        this.info = this.generateInfo();
    }
    @Override
    public Map<String, Object> generateInfo() {
        var map = new HashMap<String, Object>();
        map.put("street", this.street);
        map.put("city", this.city);
        map.put("country", this.country);
        map.put("postalCode", this.postalCode);
        return map;
    }
}
