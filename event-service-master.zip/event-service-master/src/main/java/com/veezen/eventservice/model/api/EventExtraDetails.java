package com.veezen.eventservice.model.api;


public abstract class EventExtraDetails {

    // @todo  think about how to implement this
    /// @Todo create common functions to be implemented  in all classes
}
