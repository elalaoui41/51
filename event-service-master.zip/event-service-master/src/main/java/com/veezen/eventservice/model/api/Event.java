package com.veezen.eventservice.model.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.veezen.eventservice.model.VeeUser;
import com.veezen.eventservice.model.implementation.*;
import com.veezen.eventservice.model.types.EventStatus;
import com.veezen.eventservice.model.types.EventLocationType;
import com.veezen.eventservice.model.types.EventType;
import com.veezen.eventservice.model.types.NotificationType;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.Set;
import java.util.UUID;


@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.PROPERTY)
@JsonSubTypes({
        @JsonSubTypes.Type(value = CollectiveOpenEvent.class, name = CollectiveOpenEvent.NAME),
        @JsonSubTypes.Type(value = IndividualEvent.class, name = IndividualEvent.NAME),
        @JsonSubTypes.Type(value = EventRequest.class, name = EventRequest.NAME),
})
@Schema(name = "Event", description = "Event",
        anyOf = {
                CollectiveOpenEvent.class,
                IndividualEvent.class,
                CollectiveClosedEvent.class
        },
        subTypes = {
         CollectiveOpenEvent.class,
            IndividualEvent.class,
        CollectiveClosedEvent.class
})
@Getter
@Setter
@AllArgsConstructor
public abstract class  Event {
  public  abstract String getId();
  public  abstract String getName();
  public  abstract String getDescription();
  public  abstract LocalDateTime getStartDate();
  public  abstract LocalDateTime getEndDate();
  public  abstract Set<UUID> getSpheresIds();
  public abstract Double getDailyDuration();
  public abstract Integer getDuration();
  public  abstract Integer getMaxAttendees();
  public abstract  Set<String> getAttachments();
  public abstract Set<VeeUser> getAttendees();
  public abstract VeeUser getOrginizer();
  public abstract void setOrginizer(VeeUser orginizer);
  public abstract void setAttendees(Set<VeeUser> attendees);

//  public  abstract EventType getType();

  public  abstract EventLocationType getLocationType();
  public  abstract Set<UUID> getAttendeesIds();
  public  abstract UUID getOrganizerId();
  public  abstract EventStatus getStatus();
  public abstract boolean isJoinableBy(UUID id);
  public  abstract   MeetingInfo getMeetingInfo();
  public  abstract   BillingInfo getBillingInfo();
  public    abstract  void setBillingInfo(BillingInfo billingInfo);
  public abstract EventType getType() ;
  public abstract Notification generateNotification(NotificationType type);

  public    abstract  void setMeetingInfo(MeetingInfo meetingInfo);
    static   Event from(Event event){
        throw new UnsupportedOperationException();
    }


  public abstract void setOrganizerId(UUID id) ;
}
