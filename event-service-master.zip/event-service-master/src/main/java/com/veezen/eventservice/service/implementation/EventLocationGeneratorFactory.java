package com.veezen.eventservice.service.implementation;

import com.veezen.eventservice.model.api.Event;
import com.veezen.eventservice.service.api.EventLocationService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("eventLocationGeneratorFactory")
public class EventLocationGeneratorFactory {
    private final List<EventLocationService> eventLocationServices;

    public EventLocationGeneratorFactory(List<EventLocationService> eventLocationServices) {
        this.eventLocationServices = eventLocationServices;
    }

    public <T extends Event> T generateMeetingInfo(T event) {
        return eventLocationServices.stream()
                .filter(service -> service.canHandle(event.getLocationType()))
                .findFirst()
                .map(service -> service.generateMettingInfo(event))
                .orElseThrow(() -> new IllegalArgumentException("Event location type is not supported"));
    }
}
