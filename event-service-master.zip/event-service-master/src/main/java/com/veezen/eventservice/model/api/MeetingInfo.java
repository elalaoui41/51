package com.veezen.eventservice.model.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.veezen.eventservice.model.implementation.LocalMettingInfo;
import com.veezen.eventservice.model.implementation.JitsiMeettingInfo;

import java.util.Map;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.PROPERTY)
@JsonSubTypes({
        @JsonSubTypes.Type(value = JitsiMeettingInfo.class, name = JitsiMeettingInfo.NAME),
        @JsonSubTypes.Type(value = LocalMettingInfo.class, name = LocalMettingInfo.NAME),
})
public abstract  class MeetingInfo {
    // @todo gather info for the zoom or google meet
    protected Map<String, Object> info;
    public abstract Map<String, Object> generateInfo();
    public Map<String, Object> getInfo() {
        return info;
    }

}
