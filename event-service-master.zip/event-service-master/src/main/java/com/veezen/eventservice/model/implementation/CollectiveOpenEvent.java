package com.veezen.eventservice.model.implementation;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.veezen.eventservice.model.VeeUser;
import com.veezen.eventservice.model.types.EventStatus;
import com.veezen.eventservice.model.types.EventLocationType;
import com.veezen.eventservice.model.api.Event;
import com.veezen.eventservice.model.api.MeetingInfo;
import com.veezen.eventservice.model.types.EventType;
import com.veezen.eventservice.model.types.NotificationType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.lang.Nullable;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Document(collection = "vee_CollectiveOpenEvents")
public class CollectiveOpenEvent extends Event {
    public static final String NAME = "CollectiveOpenEvent";
    private  Integer duration;
    @Id
    private String id;
    private String name;
    private String description;
    @Indexed
    private LocalDateTime startDate;

    @Transient
    private boolean joinable;
    @Indexed
    private LocalDateTime endDate;
    private Set<String> attachments;

    @Indexed
    private EventLocationType locationType;
    private Set<UUID> attendeesIds;
    private  Set<UUID> spheresIds;
    private Integer maxAttendees;
    @Transient
    private Set<VeeUser> attendees;
    @Transient
    private VeeUser orginizer;
    private EventType type;
    private UUID organizerId;
    private MeetingInfo meetingInfo;
    private EventStatus status;
    private Double dailyDuration;
     private BillingInfo billingInfo;
    public CollectiveOpenEvent(
            @Nullable @JsonProperty("name") String name,
            @Nullable @JsonProperty("description") String description,
            @Nullable @JsonProperty("startDate") LocalDateTime startDate,
            @Nullable @JsonProperty("duration") Integer duration,
            @Nullable @JsonProperty("locationType") EventLocationType locationType,
            @Nullable @JsonProperty("spheresIds") Set<UUID> spheresIds,
            @Nullable @JsonProperty("meetingInfo") MeetingInfo meetingInfo,
            @Nullable @JsonProperty("attachments") Set<String> attachments,
            @Nullable @JsonProperty("dailyDuration") Double dailyDuration,
            @Nullable @JsonProperty("attendeesIds") Set<UUID> attendeesIds,
            @Nullable @JsonProperty("organizerId") UUID organizerId,
            @Nullable @JsonProperty("maxAttendees") Integer maxAttendees
            ){
        super();
        this.name = name;
        this.description = description;
        this.attachments = attachments;
        this.startDate = startDate;
        this.meetingInfo = meetingInfo;
        this.duration = duration;
        if (duration != null && dailyDuration != null && startDate != null) {
            this.endDate = startDate.plusDays(duration)
                    .plusHours(dailyDuration.longValue())
                    .plusMinutes((long) (((dailyDuration - dailyDuration.longValue()) * 60)));
        }

        this.spheresIds = spheresIds;
        this.locationType = locationType;
        this.dailyDuration = dailyDuration;

        this.attendeesIds = attendeesIds != null ? attendeesIds: new HashSet<>();
        this.type = EventType.COLLECTIVE_OPEN;
        this.status = EventStatus.PENDING;
        this.maxAttendees = maxAttendees;
        this.organizerId = organizerId;
        this.joinable = true;
        this.id = UUID.randomUUID().toString();
    }

    public CollectiveOpenEvent(EventRequest request) {
        this(request.getName(),
                request.getDescription(),
                request.getStartDate(),
                request.getDuration(),
                request.getLocationType(),
                request.getSpheresIds(),
                request.getMeetingInfo(),
                request.getAttachments(),
                request.getDailyDuration(),
                request.getAttendeesIds(),
                request.getOrganizerId(),
                request.getMaxAttendees());
    }


    @Override
    public boolean isJoinableBy(UUID id) {
        this.joinable = this.status == EventStatus.PENDING
   //             && this.type == EventType.COLLECTIVE_OPEN
                && !this.attendeesIds.contains(id) && !this.organizerId.equals(id);
        return joinable;
    }

    @Override
    public Notification generateNotification(NotificationType type) {
        return null;
    }

    public static CollectiveOpenEvent from(Event event)
    {
        return CollectiveOpenEvent.builder()
                .name(event.getName())
                .description(event.getDescription())
                .startDate(event.getStartDate())
                .endDate(event.getEndDate())
                .locationType(event.getLocationType())
                .attendeesIds(event.getAttendeesIds())
                .organizerId(event.getOrganizerId())
                .meetingInfo(event.getMeetingInfo())
                .dailyDuration(event.getDailyDuration())
                .id(UUID.randomUUID().toString())
                .status(event.getStatus())
                .spheresIds(event.getSpheresIds())
               // .type(event.getType())

                .build();
    }

}
