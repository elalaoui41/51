package com.veezen.eventservice.controller;

import com.veezen.eventservice.model.AuthDetail;
import com.veezen.eventservice.model.Counts;
import com.veezen.eventservice.service.EventAnalyticsService;
import lombok.AllArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.lang.Nullable;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;

import java.time.LocalDateTime;

@RestController
@RequestMapping("/data")
@AllArgsConstructor
@CrossOrigin("*")
public class AnalyticsControlller {
    private final EventAnalyticsService eventAnalyticsService;

    @GetMapping("/daily")
    public Flux<Counts> getDailyCount(
            @RequestParam("start")   @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime start,
            @Nullable @RequestParam("end")    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime end,
                                          Authentication authentication) {
        if (end == null) {
            end = start.plusMonths(1);
        }
        var authDetail = (AuthDetail) authentication.getPrincipal();
        return eventAnalyticsService.countAllMyEventsInPeriodGroupedByDay(authDetail.getId(), authDetail.getRoles(), start, end);
    }
    @GetMapping("/monthly")
    public Flux<Counts> getMonthlyCount(
            @RequestParam("start" )  @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime start,
            @Nullable @RequestParam("end")   @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)LocalDateTime end,
            Authentication authentication) {
        if (end == null) {
            end = start.plusYears(1);
        }
        var authDetail = (AuthDetail) authentication.getPrincipal();
        return eventAnalyticsService
                .countAllMyEventsInPeriodGroupedByMonth(authDetail.getId(), authDetail.getRoles(), start, end);
    }
    @GetMapping("/daily/activeHours")
    public Flux<Counts> getDailyActiveHourse(@RequestParam("start" )  @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime start,
                                             @Nullable @RequestParam("end")   @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)LocalDateTime end,
                                             Authentication authentication) {
        if (end == null) {
            end = start.plusWeeks(1);
        }
        var authDetail = (AuthDetail) authentication.getPrincipal();
        return eventAnalyticsService.countDailyActiveHours(authDetail, start , end);
    }
    @GetMapping("/monthly/activeHours")
    public Flux<Counts> getMonthlyActiveHourse(@RequestParam("start" )  @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime start,
                                               @Nullable @RequestParam("end")   @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)LocalDateTime end,
                                               Authentication authentication) {
        if (end == null) {
            end = start.plusYears(1);
        }
        var authDetail = (AuthDetail) authentication.getPrincipal();
        return eventAnalyticsService.countMonthlyActiveHours(authDetail, start , end);
    }
}
