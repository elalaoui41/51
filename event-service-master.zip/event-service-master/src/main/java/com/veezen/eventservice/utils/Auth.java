package com.veezen.eventservice.utils;

import com.veezen.eventservice.model.types.UserRoles;

import java.util.Set;

public class Auth {
    public static boolean isContaingRole(Set<String> roles, UserRoles role) {

        return roles.contains(role.getName());
    }
    public static boolean isContaingRole(Set<String> roles, Set<UserRoles> requiredRoles) {
        return requiredRoles.stream().map(UserRoles::getName).anyMatch(roles::contains);
    }
}
