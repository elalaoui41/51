package com.veezen.eventservice.exceptions;

public class UnauthorisedException extends IllegalAccessException {
    public UnauthorisedException(String message) {
        super(message);
    }

}
