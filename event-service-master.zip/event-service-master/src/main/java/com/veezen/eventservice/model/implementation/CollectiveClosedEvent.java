package com.veezen.eventservice.model.implementation;

import com.veezen.eventservice.model.VeeUser;
import com.veezen.eventservice.model.api.Event;
import com.veezen.eventservice.model.api.MeetingInfo;
import com.veezen.eventservice.model.types.EventLocationType;
import com.veezen.eventservice.model.types.EventStatus;
import com.veezen.eventservice.model.types.EventType;
import com.veezen.eventservice.model.types.NotificationType;
import lombok.Data;
import org.springframework.data.annotation.Id;

import java.time.LocalDateTime;
import java.util.Set;
import java.util.UUID;

@Data
public class CollectiveClosedEvent /* extends  Event*/ {


    @Id
    private String id;
    private String name;
    private String description;
    private LocalDateTime startDate;
    private LocalDateTime endDate;
    private Double dailyDuration;
    private UUID organizerId;
    private Set<UUID> attendeesIds;
    private Set<VeeUser> attendees;
    private VeeUser organizer;
    private MeetingInfo meetingInfo;
    private EventLocationType locationType;
    private EventStatus status;
    private EventType type;
    private NotificationType notificationType;

}
