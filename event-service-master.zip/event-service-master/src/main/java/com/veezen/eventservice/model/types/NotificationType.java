package com.veezen.eventservice.model.types;

public enum NotificationType {
    EVENT_CREATION,
    EVENT_REGISTER,
    EVENT_UPDATE,
    EVENT_CANCEL,
    REQUEST_CREATION,
    REQUEST_UPDATE,
    REQUEST_CANCEL,
    REQUEST_ACCEPT,
    EVENT_DELETE,
    EVENT_JOIN,
    REQUEST_REJECT
}
