package com.veezen.eventservice.service.api;

import com.veezen.eventservice.model.AuthDetail;
import com.veezen.eventservice.model.api.Event;
import com.veezen.eventservice.model.types.NotificationType;
import reactor.core.publisher.Mono;

public abstract class NotificationService {
    public abstract Mono<Void> sendNotification(AuthDetail authDetail, Event event, NotificationType notificationType);
}
