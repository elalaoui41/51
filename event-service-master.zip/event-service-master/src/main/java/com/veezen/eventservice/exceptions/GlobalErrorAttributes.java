package com.veezen.eventservice.exceptions;


import org.apache.commons.lang3.NotImplementedException;
import org.springframework.boot.web.error.ErrorAttributeOptions;
import org.springframework.boot.web.reactive.error.DefaultErrorAttributes;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.reactive.function.server.ServerRequest;

import java.util.Map;

@Configuration
public class GlobalErrorAttributes extends DefaultErrorAttributes {

    private final Map<Class<? extends  Exception>, Integer> statusMap;

    public GlobalErrorAttributes()
    {
        super();
        statusMap = Map.of(
                IllegalAccessException.class, HttpStatus.FORBIDDEN.value(),
                UnauthorisedException.class, HttpStatus.UNAUTHORIZED.value(),
                NotImplementedException.class, HttpStatus.NOT_IMPLEMENTED.value(),
                NotFoundException.class, HttpStatus.NOT_FOUND.value());
    }
    @Override
    public Map<String, Object> getErrorAttributes(ServerRequest request,
                                                  ErrorAttributeOptions options) {

        Map<String, Object> map = super.getErrorAttributes(
                request, options);
    Throwable error = getError(request);
        map.put("status", findStatusCode(error));
        map.put("message", error.getMessage());
        map.put("timestamp", System.currentTimeMillis());
        map.put("path", request.path());
        map.put("trace", error.getStackTrace());
        return map;
    }
    private int findStatusCode(Throwable t)
    {
        if (statusMap.containsKey(t.getClass()))
        {
            return statusMap.get(t.getClass());
        }
        return HttpStatus.BAD_REQUEST.value();
    }
}

