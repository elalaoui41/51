package com.veezen.eventservice.service.implementation;

import com.veezen.eventservice.model.AuthDetail;
import com.veezen.eventservice.model.api.Event;
import com.veezen.eventservice.model.types.NotificationType;
import com.veezen.eventservice.service.api.NotificationService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Slf4j
@Service("rabbitMqNotificationService")
public class RabbitMqNotificationService extends NotificationService {


    @Override
    public Mono<Void> sendNotification(AuthDetail authDetail, Event event, NotificationType notificationType) {
        return Mono.just(event)
                .doOnEach(event1 -> log.info("Sending notification for event {}", event1))
                .then();
    }
}
