package com.veezen.eventservice.service.implementation;

import com.veezen.eventservice.dao.IndividualEventRepository;
import com.veezen.eventservice.exceptions.NotFoundException;
import com.veezen.eventservice.exceptions.UnauthorisedException;
import com.veezen.eventservice.model.AuthDetail;
import com.veezen.eventservice.model.api.Event;
import com.veezen.eventservice.model.implementation.IndividualEvent;
import com.veezen.eventservice.model.types.UserRoles;
import com.veezen.eventservice.service.api.EventService;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Set;
import java.util.UUID;

@Service("IndividualEventService")

public class IndividualEventService extends EventService {

    private final IndividualEventRepository eventDao;
    public IndividualEventService(IndividualEventRepository individualEventRepository) {
        super(individualEventRepository);
        this.eventDao = individualEventRepository;
    }

    @Override
    public Mono<? extends Event> create(AuthDetail authDetail, Event event) {
        if (!(event instanceof IndividualEvent))
            return Mono.error(new IllegalArgumentException("Event must be of type IndividualEvent"));
        if (event.getAttendeesIds().isEmpty() || event.getAttendees().size() > 1)
            return Mono.error(new IllegalArgumentException("Event must have one attendee"));
        if (event.getAttendeesIds().contains(event.getOrganizerId()))
            return Mono.error(new IllegalArgumentException("Event must not have organizer as attendee"));
        if (event.getEndDate().isBefore(event.getStartDate()))
            return Mono.error(new IllegalArgumentException("Event end date must be after start date"));
        return this.eventDao.save((IndividualEvent) event);
    }

    @Override
    public Mono<? extends Event> update(AuthDetail authDetail, String id, Event event) {
        if (!(event instanceof IndividualEvent))
            return Mono.error(new IllegalArgumentException("Event must be of type IndividualEvent"));
        if (event.getAttendeesIds().isEmpty() || event.getAttendees().size() > 1)
            return Mono.error(new IllegalArgumentException("Event must have one attendee"));
        if (event.getAttendeesIds().contains(event.getOrganizerId()))
            return Mono.error(new IllegalArgumentException("Event must not have organizer as attendee"));

        return eventDao.findById(id); // to be implimented soon
//                .switchIfEmpty(Mono.error(new NotFoundException("Event not found")))
//                .map(old -> this.refreshEvent(old, (IndividualEvent) event))
//                 .flatMap(eventDao::save);
    }

    @Override
    public Mono<? extends Event> joinEvent(AuthDetail authDetail, String id, Set<UUID> joiners) {
//        return eventDao.findById(id)
//                .switchIfEmpty(Mono.error(new NotFoundException("Event not found")))
//                .map(old -> {
//                    IndividualEvent event = (IndividualEvent) old;
//                    event.setAttendeesIds(joiners);
//                    return event;
//                })
        return Mono.error(new UnauthorisedException("individual event cannot be joined"));
    }


    @Override
    public Mono<? extends Event> getOneById(AuthDetail authDetail,
                                            String id) {
        return eventDao.findById(id);
    }

    @Override
    public Flux<? extends Event> getAll(AuthDetail authDetail) {
         return Flux.empty();
    }

    @Override
    public boolean canHandle(Event event) {
        return  event.getClass().equals(IndividualEvent.class);
    }

    @Override
    public Mono<? extends Event> accept(AuthDetail authDetail, String id) {
        return Mono.error(new UnauthorisedException("individual event cannot be accepted"));
    }


    protected  IndividualEvent refreshEvent(IndividualEvent old, IndividualEvent event) {

        if (event.getName() != null)
            old.setName(event.getName());
        if (event.getDescription() != null)
            old.setDescription(event.getDescription());
        if (event.getStartDate() != null)
            old.setStartDate(event.getStartDate());
        if (event.getEndDate() != null)
            old.setEndDate(event.getEndDate());
       if (event.getDailyDuration() != null)
            old.setDailyDuration(event.getDailyDuration());

        return old;
    }
}
