package com.veezen.eventservice.service.implementation;

import com.veezen.eventservice.model.api.Event;
import com.veezen.eventservice.model.types.EventLocationType;
import com.veezen.eventservice.service.api.EventLocationService;
import org.springframework.stereotype.Service;

@Service("localMeetingInfoService")
public class LocalMeetinInfoService extends EventLocationService {
    @Override
    public  <T extends Event> T  generateMettingInfo(T event) {
        if (event.getMeetingInfo() == null)
            throw new IllegalArgumentException("Event must have meeting info");
        return event;
    }

    @Override
    public boolean canHandle(EventLocationType type) {
        assert type != null;
        return type == EventLocationType.LOCAL;
    }
}
