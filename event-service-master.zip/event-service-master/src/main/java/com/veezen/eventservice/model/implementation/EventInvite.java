package com.veezen.eventservice.model.implementation;

import lombok.Builder;

import java.util.Set;
import java.util.UUID;

@Builder
public class EventInvite {
    private UUID ownerId;
    private Set<UUID> invitedUsers;

    public static EventInvite from(UUID ownerId, Set<UUID> invitedUsers) {
        return EventInvite.builder()
                .ownerId(ownerId)
                .invitedUsers(invitedUsers)
                .build();
    }
    public static EventInvite from(UUID ownerId) {
        return EventInvite.builder()
                .ownerId(ownerId)
                .invitedUsers(Set.of(ownerId))
                .build();
    }
}
