package com.veezen.eventservice.service.implementation;

import com.inversoft.rest.ClientResponse;
import com.veezen.eventservice.config.FusionAuthConfig;
import com.veezen.eventservice.exceptions.NotFoundException;
import io.fusionauth.client.FusionAuthClient;
import io.fusionauth.domain.User;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;

import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

@AllArgsConstructor
@Service
public class FusionAuthService {
    private final FusionAuthClient fusionAuthClient;
    private final FusionAuthConfig fusionAuthConfig;

    public Mono<User> fetchUserUsingJwt(String token) {
        return Mono.just(fusionAuthClient.retrieveUserUsingJWT(token))
                .filter(ClientResponse::wasSuccessful)
                .map(res->res.successResponse.user);
    }

    public Set<String> getUserRoles(UUID id)
    {
        var res =  fusionAuthClient.retrieveUser(id);
        if (!res.wasSuccessful())
            throw new NotFoundException("User not found");
        return res.successResponse.user.getRoleNamesForApplication(fusionAuthConfig.appId);
    }
    public Mono<Map<UUID, Set<String>>> getBulkUserRoles(Set<UUID> ids)
    {
        return Flux.fromStream(ids.stream())
                .map(id-> {
                    var roles = getUserRoles(id);
                    return Map.entry(id, roles);
                })
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
    }
}
