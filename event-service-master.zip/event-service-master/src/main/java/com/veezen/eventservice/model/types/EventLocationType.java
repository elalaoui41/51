package com.veezen.eventservice.model.types;

public enum EventLocationType {
    REMOTE,
    LOCAL
}
