package com.veezen.eventservice.dao;

import com.veezen.eventservice.model.implementation.EventRequest;
import org.springframework.stereotype.Repository;

@Repository("eventRequestRepository")
public interface EventRequestRepository extends EventDao<EventRequest> {

}
