package com.veezen.eventservice.model.types;

public enum UserRoles {
    ADMIN("Admin"),
    CLIENT("Client"),
    COACH("Coach"),
    EMPLOYEE("Employee"),
    ENTREPRISE("Enterprise"),
    ENTREPRISE_ADMIN("Enterprise_admin"),
    ENTREPRIZE_USER("Enterprise_user"),
    VEE_BOT("Vee_bot");
    private final String name;
    public String getName() {
        return name;
    }
    UserRoles(String name)
    {
        this.name = name;
    }
}
