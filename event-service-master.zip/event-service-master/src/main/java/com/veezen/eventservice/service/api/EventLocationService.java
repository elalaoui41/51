package com.veezen.eventservice.service.api;

import com.veezen.eventservice.model.api.Event;
import com.veezen.eventservice.model.api.MeetingInfo;
import com.veezen.eventservice.model.types.EventLocationType;
import org.springframework.stereotype.Service;


public abstract  class EventLocationService {

    abstract public <T extends Event> T generateMettingInfo(T event);

    abstract public boolean canHandle(EventLocationType type);
}
