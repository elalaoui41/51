package com.veezen.eventservice.model.implementation;

import com.veezen.eventservice.model.types.NotificationType;
import lombok.Builder;
import lombok.Data;

import java.util.Set;
import java.util.UUID;

@Builder
@Data
public class Notification {
    private String message;
    private UUID from;
    private String id;
    private Set<UUID> to;
    private NotificationType type;
}