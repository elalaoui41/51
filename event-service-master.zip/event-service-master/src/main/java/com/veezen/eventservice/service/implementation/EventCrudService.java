package com.veezen.eventservice.service.implementation;

import com.veezen.eventservice.exceptions.NotFoundException;
import com.veezen.eventservice.model.AuthDetail;
import com.veezen.eventservice.model.api.Event;
import com.veezen.eventservice.model.types.NotificationType;
import com.veezen.eventservice.service.api.EventService;
import com.veezen.eventservice.service.api.NotificationService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;
import java.util.*;

@AllArgsConstructor
@Service("eventService")
public class EventCrudService {
    private final List<EventService> eventServices;
    private final List<NotificationService> notificationServices;
    private final EventLocationGeneratorFactory eventLocationGeneratorFactory;

    public Mono<? extends Event> create(AuthDetail authDetail, Event event) {
        return findEventService(event)
                .flatMap(eventService -> eventService.create(authDetail, eventLocationGeneratorFactory
                        .generateMeetingInfo(event)))
                .doOnSuccess(event1 -> notify(authDetail, event1, NotificationType.EVENT_CREATION));
    }
    public Mono<? extends Event> update(AuthDetail authDetail, String id , Event event) {
        return findEventService(id)
                .flatMap(eventService -> eventService.update(authDetail,id, event))
                .doOnSuccess(event1 -> notify(authDetail, event1, NotificationType.EVENT_UPDATE));
    }

    public Mono<? extends Event> accept(AuthDetail authDetail, String id) {
     // @todo enable accept event fo just request;
        return findEventService(id)
                .flatMap(
                        eventService -> eventService.accept(authDetail,id)
                ) .flatMap(event -> create(authDetail, event));
    }

    public Mono<? extends Event> joinEvent(AuthDetail authDetail,
                                           String id,  Set<UUID> joiners) {
        return findEventService(id)
                .flatMap(eventService -> eventService.joinEvent(authDetail, id, joiners))
                .doOnSuccess(event1 -> notify(authDetail, event1, NotificationType.EVENT_JOIN));
    }
    public Flux<? extends  Event> findClosestEvents(AuthDetail authDetail)
    {
        return Flux.fromIterable(eventServices)
                .flatMap(eventService ->
                        eventService.findClosestEvent(authDetail, LocalDateTime.now()))
                .sort(Comparator.comparing(Event::getStartDate))
                .take(1);
    }


    public Mono<? extends Event> getOneById(AuthDetail authDetail, String id) {
        return findEventService(id)
                .flatMap(eventService -> eventService.getOneById(authDetail, id));
    }
    public Flux<? extends  Event> getAllInPeriod(AuthDetail authDetail,
                                                 LocalDateTime start, LocalDateTime end) {
        return Flux.fromIterable(eventServices)
                .flatMap(eventService ->
                        eventService.getAllInPeriod(authDetail, start, end));
    }

    public Mono<Void> deleteOneById(AuthDetail authDetail, String id) {
        return findEventService(id)
                .flatMap(eventService -> eventService.deleteOneById(authDetail, id))
            ;//    .doOnSuccess(event1 -> notify(authDetail, event1, NotificationType.EVENT_DELETE));
    }


    private Mono< EventService> findEventService(Event event)
    {
        return Flux.fromStream(eventServices.stream())
                .filter(eventService -> eventService.canHandle(event))
                .switchIfEmpty(Mono.error(new NotFoundException("Event type not supported")))
                .next();
    }
    private Mono< EventService> findEventService(String  id)
    {
        return Flux.fromStream(eventServices.stream())
                .filterWhen(eventService -> eventService.canHandle(id))
                .switchIfEmpty(Mono.error(new NotFoundException("Event type not supported")))
                .next();
    }
    private void notify(AuthDetail authDetail, Event event, NotificationType notificationType)
    {
        Flux.fromStream(notificationServices.stream())
                .flatMap(notificationService -> notificationService.sendNotification(authDetail, event, notificationType))
                .subscribe();
    }
}
