package com.veezen.eventservice.model;

import java.util.UUID;

public class VeeUser {
    private UUID id;
    private String fullName;
    private String email;
    private  String avatar;
}
