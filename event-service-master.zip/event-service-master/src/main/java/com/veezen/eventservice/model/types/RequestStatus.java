package com.veezen.eventservice.model.types;

public enum RequestStatus {
    PENDING,
    ACCEPTED,
    REJECTED
}
