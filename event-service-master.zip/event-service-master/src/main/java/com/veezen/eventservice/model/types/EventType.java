package com.veezen.eventservice.model.types;

public enum EventType {
    COLLECTIVE_CLOSED,
    COLLECTIVE_OPEN,
    INDIVIDUAL
}
