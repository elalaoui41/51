package com.veezen.eventservice.config;


import com.inversoft.rest.ClientResponse;
import com.veezen.eventservice.model.AuthDetail;

import com.veezen.eventservice.service.implementation.FusionAuthService;
import io.fusionauth.client.FusionAuthClient;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.ReactiveAuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.UUID;
import java.util.stream.Collectors;

@Component
public class AuthenticationManager implements ReactiveAuthenticationManager {

    private final UUID appId;

    private final FusionAuthService fusionAuthService;

    public AuthenticationManager(@Value("${fusionAuth.applicationId}") UUID appId,
                                 FusionAuthService fusionAuthService) {
        this.appId = appId;
        this.fusionAuthService = fusionAuthService;
    }
    @Override
    @SuppressWarnings("unchecked")
    public Mono<Authentication> authenticate(Authentication authentication) {
        String token = authentication.getCredentials().toString();


        return fusionAuthService.fetchUserUsingJwt(token)
                .map(user -> {
                    var roles =   user
                            .getRoleNamesForApplication(appId)
                            .stream()
                            .map(SimpleGrantedAuthority::new)
                            .collect(Collectors.toList());
                    var rolesSet = roles.stream()
                            .map(SimpleGrantedAuthority::getAuthority)
                            .collect(Collectors.toSet());
                    return new UsernamePasswordAuthenticationToken(
                           new AuthDetail(user.id, token, rolesSet ),
                            rolesSet,
                            roles);
                });
    }


}