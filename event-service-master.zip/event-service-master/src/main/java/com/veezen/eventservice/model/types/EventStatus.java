package com.veezen.eventservice.model.types;

public enum EventStatus {
    PENDING,
    HAPPNING,
    ENDED,
    ACCEPTED, INVALID
}
