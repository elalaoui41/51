package com.veezen.eventservice.model.implementation;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.veezen.eventservice.model.VeeUser;
import com.veezen.eventservice.model.api.Event;
import com.veezen.eventservice.model.api.MeetingInfo;
import com.veezen.eventservice.model.types.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.lang.Nullable;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

@Data
@AllArgsConstructor
@Document(collection = "vee_event_request")
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.PROPERTY)
@JsonTypeName(EventRequest.NAME)
@NoArgsConstructor
public class EventRequest extends Event {
    public static final String NAME = "EventRequest";
    @Id
    private String id;
    private String name;
    private String description;
    @Indexed
    private LocalDateTime startDate;

    @Transient
    private boolean joinable;
    @Indexed
    private LocalDateTime endDate;
    private Set<String> attachments;
    @Indexed
    private EventLocationType locationType;
    private Set<UUID> attendeesIds;
    private  Set<UUID> spheresIds;
    private Integer maxAttendees;
    @Transient
    private Set<VeeUser> attendees;
    @Transient
    private VeeUser orginizer;
    private EventType type;
    private UUID organizerId;
    private Integer duration;
    private MeetingInfo meetingInfo;
    private EventStatus status;
    private Double dailyDuration;
    private BillingInfo billingInfo;

    public EventRequest(
             @JsonProperty("name") String name,
             @JsonProperty("description") String description,
             @JsonProperty("startDate") LocalDateTime startDate,
             @JsonProperty("duration") Integer duration,
             @JsonProperty("locationType") EventLocationType locationType,
             @JsonProperty("type") EventType type,
             @Nullable @JsonProperty("attachments") Set<String> attachments,
             @Nullable@JsonProperty("spheresIds") Set<UUID> spheresIds,
             @JsonProperty("dailyDuration") Double dailyDuration,
            @Nullable @JsonProperty("meetingInfo") MeetingInfo meetingInfo,
            @Nullable @JsonProperty("attendeeIds") Set<UUID> attendeeIds,
             @JsonProperty("maxAttendees") Integer maxAttendees
    ){
        super();
        this.name = name;
        this.description = description;
        this.dailyDuration =dailyDuration;
        this.duration = duration;
        this.meetingInfo = meetingInfo;
        this.startDate = startDate;
        this.spheresIds = spheresIds;
        this.joinable =true;
        this.attachments = attachments;
        this.type = type;
        if (duration != null && dailyDuration != null && startDate != null) {
            this.endDate = startDate.plusDays(duration)
                    .plusHours(dailyDuration.longValue())
                    .plusMinutes((long) (((dailyDuration - dailyDuration.longValue()) * 60)));
        }
        this.status = EventStatus.PENDING;
        this.locationType = locationType;
        this.attendeesIds = attendeeIds;
        this.maxAttendees = maxAttendees;
        this.id = UUID.randomUUID().toString();

    }

    @Override
    public boolean isJoinableBy(UUID id) {
        return this.status == EventStatus.PENDING;
    }

    @Override
    public Notification generateNotification(NotificationType type) {
        return null;
    }

    public Mono<? extends Event> convertToEvent() {
        if (this.type == null)
            this.type = EventType.INDIVIDUAL;
        switch (this.type)
        {
            case INDIVIDUAL: {
                if (this.attendeesIds != null && this.attendeesIds.size()  == 1)
                     return Mono.just(new IndividualEvent(this));
            }
            case COLLECTIVE_OPEN:
                return Mono.just(new CollectiveOpenEvent(this));

        }
        return Mono.error(new IllegalArgumentException("Unknown event type"));
    }
}
