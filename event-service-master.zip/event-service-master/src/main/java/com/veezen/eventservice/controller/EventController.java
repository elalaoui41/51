package com.veezen.eventservice.controller;

import com.veezen.eventservice.model.AuthDetail;
import com.veezen.eventservice.model.api.Event;

import com.veezen.eventservice.service.implementation.EventCrudService;
import lombok.AllArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.lang.Nullable;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

@RestController
@RequestMapping("/crud")
@AllArgsConstructor
@CrossOrigin("*")
public class EventController {
    private final EventCrudService eventCrudService;

    @PostMapping("/create")
    public Mono<? extends Event> create(Authentication authentication,
                                        @RequestBody Event event) {
        var authDetail = (AuthDetail) authentication.getPrincipal();
        return eventCrudService.create(authDetail, event);
    }

    @PostMapping("/update/{id}")
    public Mono<? extends Event> update( Authentication authentication,@PathVariable("id") String id, @RequestBody Event event) {
        var authDetail = (AuthDetail) authentication.getPrincipal();
        return eventCrudService.update(authDetail,id, event);
    }

    @PostMapping("/accept/{id}")
    public Mono<? extends Event> accept(Authentication authentication,
                                        @PathVariable("id") String id) {
        var authDetail = (AuthDetail) authentication.getPrincipal();
        return eventCrudService.accept(authDetail,id);
    }
    @PostMapping("/join/{id}")
    public Mono<? extends  Event> joinEvent(
            @PathVariable("id") String id,
          @Nullable  @RequestBody Set<UUID> joiners,
            Authentication authentication

    )
    {
        var authDetail = (AuthDetail) authentication.getPrincipal();
        if (joiners == null)
            joiners = new HashSet<>();

        return eventCrudService.joinEvent(authDetail,id, joiners );
    }
    @PostMapping("/delete/{id}")
    public Mono<Void> deleteOneById(Authentication authentication,@PathVariable("id") String id) {
        var authDetail = (AuthDetail) authentication.getPrincipal();
        return eventCrudService.deleteOneById(authDetail,id);
    }

    @GetMapping("/get/{id}")
    public Mono<? extends Event> getOneById(Authentication authentication,@PathVariable("id") String id) {
        var authDetail = (AuthDetail) authentication.getPrincipal();
        return eventCrudService.getOneById(authDetail,id);
    }
    @GetMapping("/getClosest")
    public Flux<? extends Event> findClosest(Authentication authentication)
    {
        var authDetail = (AuthDetail) authentication.getPrincipal();
        return eventCrudService.findClosestEvents(authDetail);
    }

    /**
     * @param start the start of the period
     * @param end the end of the period when it null it will be next month
     * @return Mono<Event> with the event generated
     */
    @GetMapping("/me")
    public Flux<? extends Event> getMyEvents(Authentication authentication,
                                             @RequestParam("start")    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime start,
                                             @Nullable @RequestParam("end")   @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime end) {
        if (end == null) {
            end = start.plusMonths(1);
        }
        var authDetail = (AuthDetail) authentication.getPrincipal();

        return eventCrudService.getAllInPeriod(authDetail, start, end);
    }
}
