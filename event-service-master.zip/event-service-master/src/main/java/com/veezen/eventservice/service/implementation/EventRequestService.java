package com.veezen.eventservice.service.implementation;

import com.veezen.eventservice.dao.EventRequestRepository;
import com.veezen.eventservice.exceptions.NotFoundException;
import com.veezen.eventservice.exceptions.UnauthorisedException;
import com.veezen.eventservice.model.AuthDetail;
import com.veezen.eventservice.model.api.Event;
import com.veezen.eventservice.model.implementation.EventRequest;
import com.veezen.eventservice.model.types.EventStatus;
import com.veezen.eventservice.model.types.UserRoles;
import com.veezen.eventservice.service.api.EventService;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;
import java.util.Set;
import java.util.UUID;

@Service("EventRequestService")
public class EventRequestService extends EventService {
    private final EventRequestRepository eventDao;

    public EventRequestService(EventRequestRepository eventDao) {
        super(eventDao);
        this.eventDao = eventDao;
    }

    @Override
    public Mono<? extends Event> create(AuthDetail authDetail, Event event) {
        event.setOrganizerId(authDetail.getId());
        return eventDao.save((EventRequest) event);
    }

    @Override
    public Mono<? extends Event> accept(AuthDetail authDetail, String id) {
        return eventDao.findById(id)
                .filter(event -> event.getStatus() == EventStatus.PENDING)
                .switchIfEmpty(Mono.error(new NotFoundException("Event not found")))
                .flatMap(event -> {
                    event.setStatus(EventStatus.ACCEPTED);
                    return eventDao.save(event);
                })
                .flatMap(EventRequest::convertToEvent);
    }

    @Override
    public Mono<? extends Event> update(AuthDetail authDetail, String id, Event event) {
        return null;
    }

    @Override
    public Flux<? extends Event> getAllInPeriod(AuthDetail authDetail, LocalDateTime start, LocalDateTime end) {
        if (authDetail.isContainingAnyRole(Set.of(UserRoles.ADMIN.getName(), UserRoles.COACH.getName())))
            return eventDao.findAllByStartDateBetween(start, end);
        return eventDao.findAllByAttendeesIdsContainingOrOrganizerIdAndStartDateBetween(authDetail.getId(), start, end);
    }

    @Override
    public Mono<? extends Event> joinEvent(AuthDetail authDetail, String id, Set<UUID> joiners) {
        return Mono.error(new UnauthorisedException("EventRequest cannot be joined"));
    }

    @Override
    public Mono<? extends Event> getOneById(AuthDetail authDetail, String id) {
        return eventDao.findById(id);
    }

    @Override
    public Flux<? extends Event> getAll(AuthDetail authDetail) {
        return eventDao.findAll();
    }

    @Override
    public boolean canHandle(Event event) {
        return event.getClass().equals(EventRequest.class);
    }


}
