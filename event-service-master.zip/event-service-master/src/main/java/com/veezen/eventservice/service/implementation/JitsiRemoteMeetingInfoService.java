package com.veezen.eventservice.service.implementation;

import com.veezen.eventservice.model.api.Event;
import com.veezen.eventservice.model.implementation.JitsiMeettingInfo;
import com.veezen.eventservice.model.types.EventLocationType;
import com.veezen.eventservice.service.api.EventLocationService;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service("jitsiRemoteMeetingInfoService")
public class JitsiRemoteMeetingInfoService extends EventLocationService {
    @Override
    public <T extends Event> T generateMettingInfo(T event) {
        var meetingInfo = new JitsiMeettingInfo();
        meetingInfo.setPassword("randmon password");
        meetingInfo.setUrl("https://meet.veezen.com/"+ UUID.randomUUID().toString());
        meetingInfo.setToken(UUID.randomUUID().toString());
        event.setMeetingInfo(meetingInfo);
        return event;
    }

    @Override
    public boolean canHandle(EventLocationType type) {
        assert type != null;
        return type == EventLocationType.REMOTE;
    }
}

