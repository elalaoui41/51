package com.veezen.eventservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class EventServiceApplication {

//	@Bean
//	CommandLineRunner contextLoads(EventServiceFactory eventServiceFactory) {
//
//		return args-> eventServiceFactory.create(new IndividualEvent(
//				"sdfsdf", "dsfs",
//				LocalDateTime.now().minus(1, ChronoUnit.HOURS),
//				LocalDateTime.now().plus(1, ChronoUnit.HOURS),
//				"dssf", EventType.LOCAL,
//				new LocalMettingInfo("dsf",
//						"dsf",
//						"dsf",
//						45000), UUID.randomUUID(),
//				UUID.randomUUID()))
//				.subscribe(System.out::println);
//	}
	public static void main(String[] args) {
		SpringApplication.run(EventServiceApplication.class, args);
	}

}
