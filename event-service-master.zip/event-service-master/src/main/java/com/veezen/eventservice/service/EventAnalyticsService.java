package com.veezen.eventservice.service;

import com.veezen.eventservice.model.AuthDetail;
import com.veezen.eventservice.model.Counts;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;

import java.time.LocalDateTime;
import java.util.Set;
import java.util.UUID;

@Service
public class EventAnalyticsService {
    public Flux<Counts> countAllMyEventsInPeriodGroupedByDay(UUID id, Set<String> roles, LocalDateTime start, LocalDateTime end) {
        return Flux.empty();
    }

    public Flux<Counts> countAllMyEventsInPeriodGroupedByMonth(UUID id, Set<String> roles, LocalDateTime start, LocalDateTime end) {
        return Flux.empty();
    }

    public Flux<Counts> countDailyActiveHours(AuthDetail authDetail, LocalDateTime start, LocalDateTime end) {
            return Flux.empty();
    }

    public Flux<Counts> countMonthlyActiveHours(AuthDetail authDetail, LocalDateTime start, LocalDateTime end) {
        return Flux.empty();
    }
}
