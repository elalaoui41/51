package com.veezen.eventservice.service.implementation;

import com.veezen.eventservice.dao.CollectiveOpenEventRepository;
import com.veezen.eventservice.exceptions.UnauthorisedException;
import com.veezen.eventservice.model.AuthDetail;
import com.veezen.eventservice.model.api.Event;
import com.veezen.eventservice.model.implementation.CollectiveOpenEvent;
import com.veezen.eventservice.model.types.UserRoles;
import com.veezen.eventservice.service.api.EventService;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import java.time.LocalDateTime;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

@Service("CollectiveOpenEventService")
public class CollectiveOpenEventService extends EventService {
    private final CollectiveOpenEventRepository eventDao;

    public CollectiveOpenEventService(CollectiveOpenEventRepository eventDao) {
        super(eventDao);
        this.eventDao = eventDao;
    }


    @Override
    public Mono<? extends Event> create(AuthDetail authDetail, Event event) {
        if(event.getOrganizerId() == null)
            event.setOrganizerId(authDetail.getId());
        return  eventDao.save((CollectiveOpenEvent) event);
    }

    @Override
    public Mono<? extends Event> update(AuthDetail authDetail, String id, Event event) {
        return Mono.error(new UnsupportedOperationException("Not implemented yet"));
    }

    @Override
    public Mono<? extends Event> joinEvent(AuthDetail authDetail, String id, Set<UUID> joiners) {
        if (joiners == null)
            joiners = new HashSet<>();
        joiners.add(authDetail.getId());

        Set<UUID> finalJoiners = joiners;
        return eventDao.findById(id)
                .map(old ->{
                    if (old.getAttendeesIds().size() + finalJoiners.size() > old.getMaxAttendees())
                        throw new IllegalArgumentException("Too many attendees");
                    old.getAttendeesIds()
                            .addAll(finalJoiners);
                    return old;
                }).flatMap(eventDao::save);
    }
    @Override
     public Flux< ? extends  Event> getAllInPeriod(AuthDetail authDetail, LocalDateTime start, LocalDateTime end)
    {
    //    if (authDetail.isContaingRole(UserRoles.ADMIN.getName()))
            return eventDao.findAllByStartDateBetween(start, end);
 // return eventDao.findAllByAttendeesIdsContainingOrOrganizerIdAndStartDateBetween(authDetail.getId(), start, end);
    }

    @Override
    public Mono<? extends Event> getOneById(AuthDetail authDetail, String id) {
        return eventDao.findById(id);
    }

    @Override
    public Flux<? extends Event> getAll(AuthDetail authDetail) {
        return Flux.empty();
    }

    @Override
    public boolean canHandle(Event event) {
        return event.getClass().equals(CollectiveOpenEvent.class);
    }

    @Override
    public Mono<? extends Event> accept(AuthDetail authDetail, String id) {
        return Mono.error(new UnauthorisedException("CollectiveOpenEvent cannot be accepted"));
    }
}
