package com.veezen.eventservice.model;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.Set;
import java.util.UUID;

@Data
@AllArgsConstructor
public class AuthDetail {
    private UUID id;
    private String token;
    private Set<String > roles;

    public boolean isContaingRole(String role) {
        return roles.contains(role);
    }
    public boolean isContainingRoles(Set<String> roles) {
        return this.roles.containsAll(roles);
    }

    public boolean isContainingAnyRole(Set<String> roles) {
        return roles.stream().anyMatch(this.roles::contains);
    }
}
