package com.veezen.eventservice.service.api;

import com.veezen.eventservice.dao.EventDao;
import com.veezen.eventservice.exceptions.UnauthorisedException;
import com.veezen.eventservice.model.AuthDetail;
import com.veezen.eventservice.model.api.Event;
import com.veezen.eventservice.model.types.UserRoles;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;
import java.util.Set;
import java.util.UUID;

public abstract class EventService {
    protected final EventDao<? extends Event> eventDao;

    public EventService(EventDao<? extends Event> eventDao) {
        this.eventDao = eventDao;
    }

    abstract public Mono < ? extends  Event> create(AuthDetail authDetail, Event event);

    abstract public Mono < ? extends  Event> update(AuthDetail authDetail, String id, Event event);

    abstract public Mono < ? extends  Event> joinEvent(AuthDetail authDetail, String id,  Set<UUID> joiners);

     public Mono <Void> deleteOneById(AuthDetail authDetail, String id)
    {
        if (authDetail.isContaingRole(UserRoles.ADMIN.getName()))
            return eventDao.deleteById(id);
        return eventDao.findById(id)
                .flatMap(event -> {
                    if (!authDetail.getId().equals(event.getOrganizerId()))
                        return Mono.error( new UnauthorisedException("Only organizer can delete event"));
                    return eventDao.deleteById(id);
                });
    }
    public Flux< ? extends Event> findClosestEvent(AuthDetail authDetail, LocalDateTime start)
    {
        if (authDetail.isContaingRole(UserRoles.ADMIN.getName()))
            return eventDao.findAllByStartDateBetween(start, start.plusMonths(1));
        return eventDao.findAllByAttendeesIdsContainingOrOrganizerIdAndStartDateBetween(authDetail.getId(),
                start, start.plusMonths(1));
    }

    abstract public Mono < ? extends  Event> getOneById(AuthDetail authDetail, String id);

    abstract public Flux< ? extends  Event> getAll(AuthDetail authDetail);

    public Flux< ? extends  Event> getAllInPeriod(AuthDetail authDetail, LocalDateTime start, LocalDateTime end)
    {
        if (authDetail.isContaingRole(UserRoles.ADMIN.getName()))
            return eventDao.findAllByStartDateBetween(start, end);
        return eventDao.findAllByAttendeesIdsContainingOrOrganizerIdAndStartDateBetween(authDetail.getId(), start, end);
    }

    abstract public  boolean canHandle(Event event);
    public Mono<Boolean> canHandle(String id)
    {
      return   eventDao.existsById(id);
    }

    public abstract Mono<? extends Event> accept(AuthDetail authDetail, String id);
}
