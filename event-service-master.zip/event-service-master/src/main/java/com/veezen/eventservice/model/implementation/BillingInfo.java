package com.veezen.eventservice.model.implementation;

import com.veezen.eventservice.model.types.EventLocationType;
import com.veezen.eventservice.model.types.EventType;
import lombok.Builder;

import java.util.Set;
import java.util.UUID;

@Builder
public class BillingInfo {
    private Set<UUID> to;
    private Set<UUID> from;
    private Set<UUID> spheres;
    private EventType type;
    private EventLocationType locationType;
}
