package com.veezen.eventservice.model.api;


public abstract class RemoteMettingInfo extends MeetingInfo {

   public abstract String getToken();
    public  abstract String getUrl();
    public  abstract String getPassword();
}
