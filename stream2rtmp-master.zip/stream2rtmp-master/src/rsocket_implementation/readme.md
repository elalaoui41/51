the first thing the client connects
 the server store a token with an empty client 
  