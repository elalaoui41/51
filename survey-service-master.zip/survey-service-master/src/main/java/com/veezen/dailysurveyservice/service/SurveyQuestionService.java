package com.veezen.dailysurveyservice.service;

import com.veezen.dailysurveyservice.dao.SurveyQuestionRepository;
import com.veezen.dailysurveyservice.model.SurveyQuestion;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Set;

@AllArgsConstructor
@Service("SurveyQuestionService")
public class SurveyQuestionService {
    private final SurveyQuestionRepository surveyQuestionRepository;

    public Mono<SurveyQuestion> create(SurveyQuestion surveyQuestion)
    {
        return surveyQuestionRepository.save(surveyQuestion);
    }

    public Mono<SurveyQuestion> findOneById(String id)
    {
        return surveyQuestionRepository.findById(id);
    }

    public Flux<SurveyQuestion> findAll()
    {
        return surveyQuestionRepository.findAll();
    }


    public Flux<SurveyQuestion> findBulk(Set<String> qIds)
    {
        return surveyQuestionRepository.findAllByIdIn(qIds);
    }


}
