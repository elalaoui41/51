package com.veezen.dailysurveyservice.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Transient;

import java.util.Set;
import java.util.UUID;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Option {
    private String id;
    private String description;
    private int votes;
    private Boolean isSelected;
    @Transient
    private double percentage;
    private int pos;
    @JsonIgnore
    private Set<UUID> voters;

    @JsonCreator
    public Option(
            @JsonProperty("pos") int pos,
            @JsonProperty("description") String description) {
        this.id = UUID.randomUUID().toString();
        this.description = description;
        this.votes = 0;
        this.pos = pos;
        percentage = 0;
        this.isSelected = false;
        this.voters = new java.util.HashSet<>();
    }
    public void setIsSelected(UUID userId)
    {
        this.isSelected = voters.contains(userId);
    }

    public boolean addVoter(String toString) {
        if (voters.contains(UUID.fromString(toString))) {
            return false;
        }
        voters.add(UUID.fromString(toString));
        this.votes++;
        return true;
    }

    public boolean unVote(UUID id) {
        if (!voters.contains(id)) {
            return false;
        }
        voters.remove(id);
        this.votes--;
        if (votes < 0)
            votes = 0;
        return true;
    }
}
