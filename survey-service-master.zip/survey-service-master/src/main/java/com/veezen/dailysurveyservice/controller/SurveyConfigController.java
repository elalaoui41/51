package com.veezen.dailysurveyservice.controller;

import com.veezen.dailysurveyservice.model.SurveyConfig;
import com.veezen.dailysurveyservice.service.SurveyConfigService;
import lombok.AllArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/config")
@AllArgsConstructor
public class SurveyConfigController {
    private final SurveyConfigService surveyConfigService;


    @PostMapping
    public Mono<SurveyConfig> create(Authentication authentication,
                                     @RequestBody SurveyConfig surveyConfig) {
        var authDetail = (com.veezen.dailysurveyservice.model.AuthDetail) authentication.getPrincipal();

        return surveyConfigService.create(authDetail, surveyConfig);
    }

    @PostMapping("/notify")
    public Mono<SurveyConfig> notify(Authentication authentication)
    {
        var authDetail = (com.veezen.dailysurveyservice.model.AuthDetail) authentication.getPrincipal();
        return surveyConfigService.notify(authDetail);
    }

    @GetMapping("me")
    public Mono<SurveyConfig> getMyConfig(Authentication authentication)
    {

        var authDetail = (com.veezen.dailysurveyservice.model.AuthDetail) authentication.getPrincipal();
        return surveyConfigService
                .getByEntrepriseId(authDetail);
    }
    @GetMapping("/")
    @PreAuthorize(value = "hasAuthority('Admin')")
    public Flux<SurveyConfig> getAll()
    {
        return surveyConfigService.getAll();
    }
}
