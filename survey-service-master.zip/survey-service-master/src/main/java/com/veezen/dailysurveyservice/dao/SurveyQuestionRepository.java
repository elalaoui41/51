package com.veezen.dailysurveyservice.dao;

import com.veezen.dailysurveyservice.model.SurveyQuestion;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import reactor.core.publisher.Flux;

import java.util.Set;

public interface SurveyQuestionRepository extends ReactiveMongoRepository<SurveyQuestion, String> {
    Flux<SurveyQuestion> findAllByIdIn(Set<String> qIds);
}
