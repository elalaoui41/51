package com.veezen.dailysurveyservice.controller;

import com.veezen.dailysurveyservice.model.SurveyAnswer;
import com.veezen.dailysurveyservice.service.SurveyAnswerService;
import lombok.AllArgsConstructor;
import org.springframework.lang.Nullable;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@RestController
@RequestMapping("/answer")
@AllArgsConstructor
public class SurveyAnswerController {
    private final SurveyAnswerService surveyAnswerService;

    @PostMapping("")
    public Mono<SurveyAnswer> answer(Authentication authentication,
                                     @RequestBody SurveyAnswer surveyAnswer) {
        var authDetail = (com.veezen.dailysurveyservice.model.AuthDetail) authentication.getPrincipal();
        return surveyAnswerService.answer(authDetail, surveyAnswer);
    }
    @GetMapping("count")
    public Mono<Long> countWeeklyAnswers(Authentication authentication)
    {
        var authDetail = (com.veezen.dailysurveyservice.model.AuthDetail) authentication.getPrincipal();
         return surveyAnswerService.countWeeklyAnswers(authDetail);
    }
    @GetMapping("/period")
    public Flux<SurveyAnswer> getAllMyAnswersInPeriod(Authentication authentication,
                                                      @RequestParam("start") String start
                                                      ,@Nullable @RequestParam("end") String end)
    {
        var authDetail = (com.veezen.dailysurveyservice.model.AuthDetail) authentication.getPrincipal();
        var startDate = LocalDateTime.parse(start, DateTimeFormatter.ISO_LOCAL_DATE_TIME);
        LocalDateTime endDate = startDate.plusWeeks(1);
        if (end != null)
            endDate = LocalDateTime.parse(end, DateTimeFormatter.ISO_LOCAL_DATE_TIME);
        return surveyAnswerService.findAllMyAnswersInPeriod(authDetail, startDate, endDate);
    }
    @GetMapping("/today")
    public Flux<SurveyAnswer> today(Authentication authentication)
    {
        var authDetail = (com.veezen.dailysurveyservice.model.AuthDetail) authentication.getPrincipal();
        return surveyAnswerService.findAllTodayAnswers(authDetail);
    }

    @GetMapping("/{id}")
    public Mono<SurveyAnswer> findOneById(@PathVariable String id) {
        return surveyAnswerService.findOneById(id);
    }


}
