package com.veezen.dailysurveyservice.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;
import java.util.UUID;

@Data
@Document(collection = "vee_surveyAnswers")
@AllArgsConstructor
@NoArgsConstructor
public class SurveyAnswer {
    @Id
    private String id;
    private Integer vote;
    private Double votePercent;
    private UUID questionId;
    private String ownerId;
    private String entrepriseId;
    private LocalDateTime createdAt;
    private SurveyQuestionType type;
    private String message;

    @JsonCreator
    public SurveyAnswer(@JsonProperty("vote") Integer vote,
                        @JsonProperty("questionId") UUID     questionId,
                        @JsonProperty("message") String message) {
        this.vote = vote;
        this.message = message;
        this.createdAt = LocalDateTime.now();
        this.questionId = questionId;
        this.id = UUID.randomUUID().toString();
    }
}
