package com.veezen.dailysurveyservice.service;

import com.veezen.dailysurveyservice.dao.SurveyConfigRepository;
import com.veezen.dailysurveyservice.model.AuthDetail;
import com.veezen.dailysurveyservice.model.SurveyConfig;
import com.veezen.dailysurveyservice.model.SurveyQuestionType;
import lombok.AllArgsConstructor;

import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;
import java.util.Set;
import java.util.UUID;

@Service
@AllArgsConstructor
@Slf4j
public class SurveyConfigService {
    private final SurveyConfigRepository surveyConfigRepository;
    private final SurveyQuestionService surveyQuestionService;

    public Mono<SurveyConfig> create(AuthDetail authDetail,
                                     SurveyConfig surveyConfig)
    {

        return getByEntrepriseId(authDetail)
                .switchIfEmpty(Mono.just(surveyConfig))
                .map(s->{
                    s.setTo(authDetail.getEntrepriseId());
                    s.setLastShow(s.getNextShow());
                    s.setNextShow(surveyConfig.getNextShow());
                    s.setQuestionIds(surveyConfig.getQuestionIds());
                    return s;
                })
                .flatMap(surveyConfigRepository::save);
    }

    public Mono<SurveyConfig> getByEntrepriseId(AuthDetail authDetail)
    {
        return surveyConfigRepository.findByTo(authDetail.getEntrepriseId())
                .map(s->{
                    s.setIsAnswered(authDetail.getId());
                    if (s.getNotifications() != null && s.getNotifications().containsKey(authDetail.getId()))
                        s.setNumberOfNotifications(s.getNotifications().get(authDetail.getId()));
                    else
                        s.setNumberOfNotifications(0);
                    return s;
                })
                .flatMap(this::injectQuestions);
    }

    public Flux<SurveyConfig> getNext5MinSurveyShow(LocalDateTime start)
    {
        return surveyConfigRepository.findAllByNextShowBetween(start,
                start.plusMinutes(5));
    }

    @Scheduled(cron = "0 0 0 * * *")
    public void updateSurveyConfig()
    {
        surveyConfigRepository.findAll().
                flatMap(s->{
                    s.setLastShow(s.getNextShow());
                    s.setNextShow(s.getNextShow().plusDays(1));
                    if (s.getAnswredBy()!= null)
                        s.getAnswredBy().clear();
                    if (s.getNotifications() != null)
                        s.getNotifications().clear();
                    return surveyConfigRepository.save(s);
                })
                .doOnEach(s-> log.info("SurveyConfig updated: " + s))
                .subscribe();
    }

    private  Mono<SurveyConfig> injectQuestions(SurveyConfig surveyConfig) {
        return surveyQuestionService.findBulk(surveyConfig.getQuestionIds())
                .collectList()
                .map(qlist->{
                    surveyConfig.setQuestions(Set.copyOf(qlist));
                    return surveyConfig;
                });
    }

    public Flux<SurveyConfig> getAll() {
        return surveyConfigRepository.findAll();
    }

    public Mono<SurveyConfig> notify(AuthDetail authDetail) {
        return getByEntrepriseId(authDetail)
                .flatMap(s->{
                    if (!s.getNotifications().containsKey(authDetail.getId()))
                        s.getNotifications().put(authDetail.getId(), 1);
                    else
                        s.getNotifications().put(authDetail.getId(), s.getNotifications().get(authDetail.getId())+1);
                    s.setNumberOfNotifications(s.getNotifications().get(authDetail.getId()));
                    return surveyConfigRepository.save(s);
                });
    }
}
