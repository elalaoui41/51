package com.veezen.dailysurveyservice.service;

import com.inversoft.rest.ClientResponse;

import com.veezen.dailysurveyservice.config.FusionAuthConfig;
import com.veezen.dailysurveyservice.exceptions.NotFoundException;
import com.veezen.dailysurveyservice.model.AuthDetail;
import io.fusionauth.client.FusionAuthClient;
import io.fusionauth.domain.User;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class FusionAuthService {
    private final FusionAuthClient fusionAuthClient;
    private final FusionAuthConfig fusionAuthConfig;

    private final WebClient webClient;

    public FusionAuthService(FusionAuthClient fusionAuthClient,
                             @Value("${veezen.account-service.base-url}") String accountServiceBaseUrl,
                             FusionAuthConfig fusionAuthConfig) {
        this.fusionAuthClient = fusionAuthClient;
        this.fusionAuthConfig = fusionAuthConfig;
        this.webClient = WebClient.builder()
                .baseUrl(accountServiceBaseUrl).build();
    }

    public Mono<User> fetchUserUsingJwt(String token) {
        return Mono.just(fusionAuthClient.retrieveUserUsingJWT(token))
                .filter(ClientResponse::wasSuccessful)
                .map(res->res.successResponse.user);
    }
    @SuppressWarnings("unchecked")
    public Mono<Map> fetchAccountUsingJwt(String token)
    {
            return webClient.get()
                    .uri("/auth/getUserUsingJwt")
                    .header("Authorization", "Bearer " + token)
                    .retrieve()
                    .bodyToMono(Map.class);
    }
    public Flux<Map> fetchAllUsersByEntrepriseId(AuthDetail authDetail)
    {
        return webClient.get()
                .uri("/fetch/entreprise/users")
                .header("Authorization", "Bearer " + authDetail.getToken())
                .retrieve()
                .bodyToFlux(Map.class);
    }
    public Set<String> getUserRoles(UUID id)
    {
        var res =  fusionAuthClient.retrieveUser(id);
        if (!res.wasSuccessful())
            throw new NotFoundException("User not found");
        return res.successResponse.user.getRoleNamesForApplication(fusionAuthConfig.appId);
    }

    public Flux<AuthDetail> retrieveBulkUsers(Set<UUID> userIds) {
        return Flux.fromIterable(userIds)
                .map(fusionAuthClient::retrieveUser)
                .filter(ClientResponse::wasSuccessful)
                .map(res -> res.successResponse.user)
                .map(user -> AuthDetail.builder()
                        .avatarUrl(user.imageUrl.toString())
                        .fullName(user.fullName)
                        .userName(user.username)
                        .roles(user.getRoleNamesForApplication(fusionAuthConfig.appId))
                        .id(user.id)
                        .build());
    }


    public Mono<Map<UUID, Set<String>>> getBulkUserRoles(Set<UUID> ids)
    {
        return Flux.fromStream(ids.stream())
                .map(id-> {
                    var roles = getUserRoles(id);
                    return Map.entry(id, roles);
                })
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
    }
}
