package com.veezen.dailysurveyservice.service;

import com.veezen.dailysurveyservice.dao.PollRepository;
import com.veezen.dailysurveyservice.exceptions.NotFoundException;
import com.veezen.dailysurveyservice.exceptions.UnauthorisedException;
import com.veezen.dailysurveyservice.model.AuthDetail;
import com.veezen.dailysurveyservice.model.Option;
import com.veezen.dailysurveyservice.model.Poll;
import lombok.AllArgsConstructor;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;
import java.util.Set;

@Service
@AllArgsConstructor
public class PollService {
    private final PollRepository pollRepository;


    public Mono<Poll> create(AuthDetail authDetail, Poll poll) {
        poll.setEntrepriseId(authDetail.getEntrepriseId().toString());
        poll.setOwnerId(authDetail.getId().toString());

        return getLastPoll(authDetail)
                .flatMap(lastPoll -> {
                    lastPoll.setActive(false);
                    return pollRepository.save(lastPoll);
                })
                .switchIfEmpty(Mono.just(poll))
                .flatMap(p -> pollRepository.save(poll));
    }

    public Mono<Poll> getLastPoll(AuthDetail authDetail) {
        return pollRepository
                .findByEntrepriseIdAndActive(
                        authDetail.getEntrepriseId().toString(),
                        true)
                .map(p ->
                {
                    p.getOptions().forEach(o -> o.setIsSelected(authDetail.getId()));
                   var total = p.getOptions().stream().map(Option::getVoters).map(Set::size)
                            .reduce(0, Integer::sum);
                   p.getOptions().forEach(o ->
                           o.setPercentage(100.0 * o.getVoters().size() / total));
                    if (p.getOptions().stream().anyMatch(Option::getIsSelected))
                        p.setVoted(true);
                    return p;
                });
    }
    @Scheduled(fixedDelay = 1000 * 60 * 60)
    private void endPolls()
    {
        pollRepository.findAllByClosedAndUntilBefore(false,
                        LocalDateTime.now())
                .map(p ->
                {
                    p.setClosed(true);
                    return p;
                }).flatMap(pollRepository::save).subscribe();
    }
    public Mono<Poll> vote(String id, String opetionId, AuthDetail authDetail) {
        return pollRepository
                .findById(id)
                .flatMap(poll -> {

                    var poolOption = poll.getOptions().stream()
                            .filter(option -> option.getId().equals(opetionId))
                            .findFirst()
                            .orElseThrow(() -> new NotFoundException("Option not found"));
                    poll.getOptions()
                            .forEach(op -> op.unVote(authDetail.getId()));
                    if (poolOption.addVoter(authDetail.getId().toString())) {
                        return pollRepository.save(poll);
                    }
                    return pollRepository.save(poll);
                }).switchIfEmpty(Mono.error(new NotFoundException("Poll not found")));
    }


    public Mono<Poll> endPoll(String id, AuthDetail authDetail) {
        return pollRepository
                .findById(id)
                .filter(poll -> poll.getOwnerId().equals(authDetail.getId().toString()))
                .flatMap(poll -> {
                    poll.setClosed(true);
                    return pollRepository.save(poll);
                })
                .switchIfEmpty(Mono.error(new UnauthorisedException("Only the owner can end the poll")));
    }

    public Mono<Poll> getPollById(String pollId) {
        return pollRepository
                .findById(pollId);
    }
}
