package com.veezen.dailysurveyservice.service;


import com.veezen.dailysurveyservice.dao.SurveyAnswerRepository;
import com.veezen.dailysurveyservice.dao.SurveyConfigRepository;
import com.veezen.dailysurveyservice.model.AuthDetail;
import com.veezen.dailysurveyservice.model.Counts;
import com.veezen.dailysurveyservice.model.SurveyAnswer;
import lombok.AllArgsConstructor;
import org.springframework.cglib.core.Local;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.time.LocalDateTime;

@AllArgsConstructor
@Service
public class SurveyAnswerService {
    private SurveyAnswerRepository surveyAnswerRepository;
    private SurveyQuestionService surveyQuestionService;
    private SurveyConfigRepository surveyConfigRepository;

    public Mono<SurveyAnswer> answer(AuthDetail authDetail, SurveyAnswer surveyAnswer) {
        return surveyQuestionService.findOneById(surveyAnswer.getQuestionId().toString())
                .switchIfEmpty(Mono.error(new IllegalArgumentException("Question not found")))
                .map(q -> {
                    surveyAnswer.setType(q.getType());
                    surveyAnswer.setVotePercent((
                            1.0 * surveyAnswer.getVote()
                            / q.getNumberOfAnswers())
                            * 100.0);
                    surveyAnswer.setOwnerId(authDetail.getId().toString());
                    surveyAnswer.setEntrepriseId(authDetail.getEntrepriseId().toString());
                    return surveyAnswer;
                }).flatMap(surveyAnswerRepository::save)
                .doOnSuccess(s-> surveyConfigRepository.findByTo(authDetail.getEntrepriseId())
                        .flatMap(sc->{
                            sc.getAnswredBy().add(authDetail.getId());
                            return surveyConfigRepository.save(sc);
                        })
                        .subscribe());
    }

    public Flux<SurveyAnswer> findAllMyAnswersInPeriod(AuthDetail authDetail, LocalDateTime start, LocalDateTime end)
    {
        return surveyAnswerRepository.findAllByOwnerIdAndCreatedAtBetween(authDetail
                        .getId().toString(),
                        start ,
                        end);
    }
    public Flux<SurveyAnswer> findAllTodayAnswers(AuthDetail authDetail)
    {
        return surveyAnswerRepository.findAllByEntrepriseIdAndCreatedAtBetween(authDetail
                        .getEntrepriseId().toString(),
                        LocalDateTime.now()
                                .withHour(0).withMinute(0).withSecond(0),
                        LocalDateTime.now()
                                .withHour(23).withMinute(59).withSecond(59));
    }


    public Mono<SurveyAnswer> findOneById(String id)
    {
        return surveyAnswerRepository.findById(id);
    }

    public Mono<Long> countWeeklyAnswers(AuthDetail authDetail) {
        return surveyAnswerRepository.countAllInWeek(authDetail
                        .getEntrepriseId().toString(),
                        LocalDateTime.now().minusDays(7).withHour(0).withMinute(0).withSecond(0),
                        LocalDateTime.now()
                                .withHour(23).withMinute(59).withSecond(59));
    }
}
