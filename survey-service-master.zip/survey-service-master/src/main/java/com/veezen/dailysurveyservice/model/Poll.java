package com.veezen.dailysurveyservice.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.lang.Nullable;

import java.time.LocalDateTime;
import java.util.Set;
import java.util.UUID;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Document(collection = "vee_polls")
public class Poll {
    @Id
    private String id;
    private String name;
    private String description;
    private String ownerId;
    private String entrepriseId;
    private LocalDateTime createdAt;
    private LocalDateTime until;
    private boolean voted;
    private boolean active;
    private boolean closed;
    private Set<Option> options;


    public Poll(@Nullable @JsonProperty("name") String name,
                @Nullable @JsonProperty("description") String description,
                @Nullable @JsonProperty("until") LocalDateTime until,
                @Nullable @JsonProperty("options") Set<Option> options) {
        this.name = name;
        this.id = UUID.randomUUID().toString();
        this.description = description;
        this.options = options;
        this.until = until;
        this.active = true;
        this.closed = false;
        this.createdAt = LocalDateTime.now();
    }
}
