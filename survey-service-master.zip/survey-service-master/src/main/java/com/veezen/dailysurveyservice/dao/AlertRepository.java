package com.veezen.dailysurveyservice.dao;

import com.veezen.dailysurveyservice.model.Alert;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import reactor.core.publisher.Flux;

import java.time.LocalDateTime;

public interface AlertRepository extends ReactiveMongoRepository<Alert, String> {


    Flux<Alert> findAllByEntrepriseIdAndCreatedAtBetweenOrderByCreatedAt(String entrepriseId,
                                                                         LocalDateTime start, LocalDateTime end);

}
