package com.veezen.dailysurveyservice.model;

import lombok.Builder;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Builder
@Data
public class PeriodCount {
    private LocalDate date;
    private int value;
    private int votesNb;

    @Override
    public boolean equals(Object o) {

        PeriodCount that = (PeriodCount) o;
        return date.equals(that.date);
    }

    public void increment() {
        System.out.println("increment");
        value++;
    }
}
