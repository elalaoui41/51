package com.veezen.dailysurveyservice.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Document(collection = "vee_alerts")
public class Alert {
    @Id
    private String id;
    private Map<Double, String> moods = new HashMap<>();
    private String entrepriseId;
    @Transient
    private Map<Double, AuthDetail> users = new HashMap<>();
    private LocalDateTime createdAt;

}
