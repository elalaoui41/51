package com.veezen.dailysurveyservice.service;

import com.veezen.dailysurveyservice.dao.AlertRepository;
import com.veezen.dailysurveyservice.dao.SurveyAnswerRepository;
import com.veezen.dailysurveyservice.model.Alert;
import com.veezen.dailysurveyservice.model.AuthDetail;
import com.veezen.dailysurveyservice.model.PeriodCount;
import com.veezen.dailysurveyservice.model.SurveyAnswer;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.reactivestreams.Publisher;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
@Slf4j
public class AlertService {
    private AlertRepository alertRepository;
    private SurveyAnswerRepository surveyAnswerRepository;
    private FusionAuthService fusionAuthService;

    @Scheduled(cron = "0 0/23 16 * * *" )
    public void generateAlerts()
    {

        var map = new HashMap<String, Alert>();
         surveyAnswerRepository.findAllByCreatedAtAfter(
                 LocalDateTime.now().minusDays(30)
         )
                // .doOnEach(a -> log.info("{}", a))
                 .groupBy(SurveyAnswer::getEntrepriseId)
                 .doOnEach(l -> log.info("now on the {}", l))
           .map(g-> {
               map.put(g.key(), Alert.builder()
                       .entrepriseId(g.key())
                       .createdAt(LocalDateTime.now())
                       .id(UUID.randomUUID().toString())
                       .build());
               return g
                       .doOnEach(l -> log.info("now on the {}", l))
                       .groupBy(SurveyAnswer::getOwnerId)
                       .map(l -> {
                           var alert = map.get(g.key());
                           var userId = l.key();
                           PeriodCount pc = PeriodCount.builder()
                                   .value(0)
                                   .votesNb(0)
                                   .build();
                           log.info("userId {}", userId);
                           return g.reduce(pc, (p1, p2) -> {
                               p1.increment();
                               p1.setVotesNb((int) (p1.getVotesNb() + p2.getVotePercent()));
                               log.info("p1 {}", p1);
                               return p1;
                           }).map(p -> {
                               p.setValue(p.getVotesNb() / p.getValue());
                               if (p.getValue() < 50)
                                   alert.getMoods().put((double) p.getValue(), userId);
                               return p;
                           });
                       });
           }).collectList()
                 .flatMapIterable(l ->  map.values())
                 .doOnEach(l -> log.info("finish and found {}", l))
                 .flatMap(l -> alertRepository.save(l))
                 .subscribe(l -> log.info("saved {}", l));
    }

    public Flux<Alert> getMyAlerts(AuthDetail authDetail)
    {
        return alertRepository.findAllByEntrepriseIdAndCreatedAtBetweenOrderByCreatedAt(
                authDetail.getEntrepriseId().toString(), LocalDateTime.now().minusDays(5),
                LocalDateTime.now())
                .flatMap(this::injectUsers);
    }

    private Mono<Alert> injectUsers(Alert alert) {
        var userIds = alert.getMoods().values().stream().map(UUID::fromString).collect(Collectors.toSet());
        return fusionAuthService.retrieveBulkUsers(userIds)
                .map(user-> {
                    var percent = alert.getMoods().
                            entrySet().stream()
                            .filter(e -> user.getId().toString().equals(e.getValue()))
                            .map(Map.Entry::getKey)
                            .findFirst()
                            .orElse(0.0);
                    user.setAverageMood(percent);
                     alert.getUsers().put(percent, user);
                     return user;
                }).collectList()
                .map(l -> alert);
    }
}
