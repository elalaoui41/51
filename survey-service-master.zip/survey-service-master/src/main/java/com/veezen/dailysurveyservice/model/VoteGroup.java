package com.veezen.dailysurveyservice.model;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class VoteGroup {
    private Integer vote;
    private Integer count;

   public void increment() {
       count++;
   }
   @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        VoteGroup voteGroup = (VoteGroup) o;
        return vote.equals( voteGroup.vote);
    }
}
