package com.veezen.dailysurveyservice.model;

public enum SurveyQuestionType {
    BATTERY,
    ESPRIT,
    MOOD,
    TEXT,
    REGULAR
}
