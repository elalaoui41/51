package com.veezen.dailysurveyservice.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Builder
@Data
public class MoodCount {
    private LocalDate date;
    private List<VoteGroup> votes;

    public MoodCount addVote(VoteGroup vote) {
        if (votes == null)
            votes = new ArrayList<>();
        if (votes.contains(vote))
            votes.get(votes.indexOf(vote)).increment();
        else
            votes.add(vote);
        return this;
    }
}
