package com.veezen.dailysurveyservice.controller;

import com.veezen.dailysurveyservice.model.Alert;
import com.veezen.dailysurveyservice.model.AuthDetail;
import com.veezen.dailysurveyservice.service.AlertService;
import lombok.AllArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;

@RestController
@RequestMapping("/alert")
@AllArgsConstructor
public class AlertController {
    private final AlertService alertService;

    @GetMapping("me")
    public Flux<Alert> getAllMyAlerts(Authentication authentication)
    {
        var authDetail = (AuthDetail) authentication.getPrincipal();
        return alertService.getMyAlerts(authDetail);
    }
}
