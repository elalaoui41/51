package com.veezen.dailysurveyservice.model;


import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.lang.Nullable;

import java.time.LocalDateTime;
import java.util.UUID;

@Data
@Document(collection = "vee_SurveyQuestions")
@NoArgsConstructor
@AllArgsConstructor
public  class SurveyQuestion {
    @Id
    private String id;
    private String text;
    private SurveyQuestionType type;
    private Integer numberOfAnswers;

    public SurveyQuestion(
            @Nullable @JsonProperty("text") String text,
            @Nullable @JsonProperty("type") SurveyQuestionType type,
            @Nullable @JsonProperty("numberOfAnswers") Integer numberOfAnswers) {
        this.text = text;
        this.type = type;
        this.numberOfAnswers = numberOfAnswers;
        this.id = UUID.randomUUID().toString();
    }
}
