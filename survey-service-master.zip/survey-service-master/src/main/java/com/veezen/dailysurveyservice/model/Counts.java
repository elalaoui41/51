package com.veezen.dailysurveyservice.model;

import lombok.Builder;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import java.util.HashSet;
import java.util.Set;


@Data
@Builder
@Slf4j
public class Counts {

    private int status;
    private Set<PeriodCount> data = new HashSet<>();
    private int lastMax;

    public void addMood(PeriodCount count) {

       var op =  data.stream()
               .filter(c -> c.equals(count))
               .findAny();

       if (op.isEmpty())
           data.add(count);
       else
           op.get().increment();
    }


    public Counts mapAll(int max, int newMax)
    {
        lastMax = max;
       data.forEach(c -> c.setValue((int) (c.getValue() * newMax / max)));
        return this;
    }
    public int getMax()
    {
        final int[] max = {0};
        data.forEach(c -> {
            if (c.getValue() > max[0])
                max[0] = c.getValue();
        });
        return max[0];
    }


    public Counts print() {
      log.info("Counts {}, size :  {}" ,status, data.size());
      log.info("valuees");
        data.forEach(c -> log.info("{}", c.getValue()));
        log.info("values end");
        return this;
    }
}
