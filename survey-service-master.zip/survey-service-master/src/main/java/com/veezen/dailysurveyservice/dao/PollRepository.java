package com.veezen.dailysurveyservice.dao;

import com.veezen.dailysurveyservice.model.Poll;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;

public interface PollRepository extends ReactiveMongoRepository<Poll, String> {
    Mono<Poll> findByEntrepriseIdAndActive(String entrepriseId, boolean active);
    Flux<Poll> findAllByClosedAndUntilBefore(boolean closed, LocalDateTime now);
}
