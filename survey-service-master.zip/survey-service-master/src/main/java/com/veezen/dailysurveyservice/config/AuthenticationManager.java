package com.veezen.dailysurveyservice.config;


import com.veezen.dailysurveyservice.model.AuthDetail;
import com.veezen.dailysurveyservice.service.FusionAuthService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.ReactiveAuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.UUID;
import java.util.stream.Collectors;

@Component
public class AuthenticationManager implements ReactiveAuthenticationManager {

    private final UUID appId;

    private final FusionAuthService fusionAuthService;

    public AuthenticationManager(@Value("${fusionAuth.applicationId}") UUID appId,
                                 FusionAuthService fusionAuthService) {
        this.appId = appId;
        this.fusionAuthService = fusionAuthService;
    }
    @Override
    @SuppressWarnings("unchecked")
    public Mono<Authentication> authenticate(Authentication authentication) {
        String token = authentication.getCredentials().toString();


        return fusionAuthService.fetchUserUsingJwt(token)
                .map(user -> {
                    var roles =   user
                            .getRoleNamesForApplication(appId)
                            .stream()
                            .map(SimpleGrantedAuthority::new)
                            .collect(Collectors.toList());
                    var rolesSet = roles.stream()
                            .map(SimpleGrantedAuthority::getAuthority)
                            .collect(Collectors.toSet());
                    return new UsernamePasswordAuthenticationToken(

                                AuthDetail.builder().id(user.id)
                                        .token(token)
                                        .roles(rolesSet)
                                        .build(),
                            rolesSet,
                            roles);
                })
                .flatMap(this::injectAccount);
    }

    private Mono<Authentication>
    injectAccount(UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken) {
        var authDetail = (AuthDetail) usernamePasswordAuthenticationToken
                .getPrincipal();
        return fusionAuthService.
                fetchAccountUsingJwt(authDetail.getToken())
                .map(account -> {
                    if (account.containsKey("entrepriseId"))
                        authDetail
                            .setEntrepriseId(UUID.fromString((String)account
                                    .get("entrepriseId")));
                    return new UsernamePasswordAuthenticationToken(authDetail,
                            usernamePasswordAuthenticationToken.getCredentials(),
                            usernamePasswordAuthenticationToken.getAuthorities());
                });
    }


}