package com.veezen.dailysurveyservice.controller;

import com.veezen.dailysurveyservice.model.SurveyQuestion;
import com.veezen.dailysurveyservice.service.SurveyQuestionService;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Set;

@RestController
@RequestMapping("/question")
@AllArgsConstructor
public class SurveyQuestionController {

    private final SurveyQuestionService surveyQuestionService;

    @PostMapping("/create")
    public Mono<SurveyQuestion> create(@RequestBody SurveyQuestion surveyQuestion) {
        return surveyQuestionService.create(surveyQuestion);
    }

    @GetMapping("/{id}")
    public Mono<SurveyQuestion> findOneById(@PathVariable String id) {
        return surveyQuestionService.findOneById(id);
    }

    @GetMapping
    public Flux<SurveyQuestion> findAll() {
        return surveyQuestionService.findAll();
    }
    @GetMapping("/bulk")
    public Flux<SurveyQuestion> fetchBulk(@RequestBody Set<String> qIds) {
        return surveyQuestionService.findBulk(qIds);
    }
}
