package com.veezen.dailysurveyservice.model;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class MoodModel {
    private int status;
    private long value;
}
