package com.veezen.dailysurveyservice.exceptions;


public class UnauthorisedException extends IllegalAccessException {
    public UnauthorisedException(String message) {
        super(message);
    }

}
