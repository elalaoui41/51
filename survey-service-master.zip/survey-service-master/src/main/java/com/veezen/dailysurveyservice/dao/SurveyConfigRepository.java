package com.veezen.dailysurveyservice.dao;

import com.veezen.dailysurveyservice.model.SurveyConfig;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;
import java.util.UUID;

public interface SurveyConfigRepository extends ReactiveMongoRepository<SurveyConfig, String> {
    Mono<SurveyConfig> findByTo(UUID to);
    Flux<SurveyConfig> findAllByNextShowBetween(LocalDateTime start, LocalDateTime end);
}
