package com.veezen.dailysurveyservice.dao;

import com.veezen.dailysurveyservice.model.SurveyAnswer;
import com.veezen.dailysurveyservice.model.SurveyQuestionType;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;

public interface SurveyAnswerRepository extends ReactiveMongoRepository<SurveyAnswer, String> {
    Flux<SurveyAnswer> findAllByCreatedAtAfter(LocalDateTime start);
    Flux<SurveyAnswer> findAllByOwnerIdAndCreatedAtBetween(String ownerId, LocalDateTime start, LocalDateTime end);
    Flux<SurveyAnswer> findAllByEntrepriseIdAndCreatedAtBetween(String entrepriseId,
                                                                LocalDateTime start, LocalDateTime end);
    @Query(value = " {$and: [" +
            " {$or:" +
            "[" +
            "{'ownerId': ?0 }," +
            "{'entrepriseId': ?0}" +
            "]}," +
            " {'createdAt': " +
            "{ $gte: ?1 , $lte: ?2 }}," +
            "{'type': ?3}" +
            "]}"
            ,fields = "{'votePercent' :  1,'vote': 1, 'type':  1,'createdAt':  1}")
    Flux<SurveyAnswer> findAllVotesInperiod(String objectId,
                                            LocalDateTime start,
                                            LocalDateTime end, SurveyQuestionType type);
    Flux<SurveyAnswer> findAllByEntrepriseIdAndTypeAndCreatedAtBetween(
            String entrepriseId,
            SurveyQuestionType type,
                                                                       LocalDateTime start,
                                                                       LocalDateTime end);
    @Query(value = " {$and: [" +
            "{'entrepriseId': ?0}," +
            " {'createdAt': " +
            "{ $gte: ?1 , $lte: ?2 }}," +
            "{'votePercent': " +
            "{ $gte: ?3 , $lte: ?4 }},"+
            "{'type': ?5}" +
            "]}"
            ,fields = "{'ownerId' :  1}")
    Flux<SurveyAnswer> findAllVotersInAday(String entrepriseId, LocalDateTime start, LocalDateTime end,
                                           double percentStart,
                                           double percentEnd, SurveyQuestionType type);

    @Query(value = " {$and: [" +
            " {$or:" +
            "[" +
            "{'ownerId': ?0 }," +
            "{'entrepriseId': ?0}" +
            "]}," +
            " {'createdAt': " +
            "{ $gte: ?1 , $lte: ?2 }}" +
            "]}"
            ,fields = "{'votePercent' :  1,'vote': 1, 'type':  1,'createdAt':  1}")
    Flux<SurveyAnswer> findAllVotesInperiod(String toString, LocalDateTime start, LocalDateTime plusWeeks);


    @Query(value = " {$and: [" +
            " {$or:" +
            "[" +
            "{'ownerId': ?0 }," +
            "{'entrepriseId': ?0}" +
            "]}," +
            " {'createdAt': " +
            "{ $gte: ?1 , $lte: ?2 }}" +
            "]}"
            ,count = true)
    Mono<Long> countAllInWeek(String toString, LocalDateTime withSecond, LocalDateTime withSecond1);

}