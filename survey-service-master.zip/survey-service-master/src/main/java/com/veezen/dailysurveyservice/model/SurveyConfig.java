package com.veezen.dailysurveyservice.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;
import java.util.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Document(collection = "vee_surveyConfigs")
public class SurveyConfig {
    @Id
    private String id;
    private LocalDateTime createdAt;
    private LocalDateTime nextShow;
    private LocalDateTime lastShow;
    private Set<String> questionIds;
    @Transient
    private Set<SurveyQuestion> questions;
    private Set<UUID> answredBy = new HashSet<>();
    @JsonIgnore
    private Map<UUID, Integer> notifications = new HashMap<>();

    @Transient
    private Integer numberOfNotifications;
    private UUID to;
    private boolean isAnswered;

    public SurveyConfig(@JsonProperty("nextShow") LocalDateTime nextShow,
                        @JsonProperty("questionIds") Set<String> questionIds) {
        this.nextShow = nextShow;
        this.questionIds = questionIds;
        this.createdAt = LocalDateTime.now();
        this.id = UUID.randomUUID().toString();
    }

    public void setIsAnswered(UUID userId)
    {
        if (this.answredBy == null)
            this.isAnswered = false;
        else
            this.isAnswered = this.answredBy.contains(userId);
    }

}
