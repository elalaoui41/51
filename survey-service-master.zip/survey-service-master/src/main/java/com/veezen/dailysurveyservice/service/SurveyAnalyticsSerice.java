package com.veezen.dailysurveyservice.service;

import com.veezen.dailysurveyservice.dao.SurveyAnswerRepository;
import com.veezen.dailysurveyservice.model.*;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.GroupedFlux;
import reactor.core.publisher.Mono;
import reactor.util.function.Tuples;

import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

@Service
@Slf4j
@AllArgsConstructor
public class SurveyAnalyticsSerice {
    private final SurveyAnswerRepository surveyAnswerRepository;
    private final FusionAuthService fusionAuthService;
    private final SurveyQuestionService surveyQuestionService;
//    private final SurveyAnswerRepository surveyAnswerService;
    private final SurveyConfigService surveyConfigService;


    public Flux<Map> createRandomAnswers(AuthDetail authDetail)
    {
        var config = surveyConfigService.getByEntrepriseId(authDetail);
         var users = fusionAuthService.fetchAllUsersByEntrepriseId(authDetail);
        return config.flatMapMany(c -> users.map(u -> Tuples.of(u , c )))
                .doOnEach(l -> log.info("now on the {}", l))
                .flatMap(map->
                        createRandomAnswersForUser(authDetail,
                                map.getT1(), map.getT2())
                        );
    }

    private Mono<Map> createRandomAnswersForUser(AuthDetail authDetail,
                                                 Map map,
                                                 SurveyConfig surveyConfig)
    {
        return Flux.fromStream(surveyConfig.getQuestions().stream())
                .flatMap(question-> this.createMonthlyRandomAnswers(authDetail, map,question))
                .last()
                .map(l->  map);

    }

    private Flux<SurveyAnswer> createMonthlyRandomAnswers(AuthDetail authDetail,
                                                          Map map,
                                                          SurveyQuestion question) {

        return toDays(LocalDateTime.now().minusMonths(1))
                .doOnEach(l -> log.info("on date:{}", l))
                .flatMap(day ->
                    surveyAnswerRepository.save(createRandomAnswer(authDetail, map,
                           question, day))
                );

    }

    private SurveyAnswer createRandomAnswer(AuthDetail authDetail,
                                            Map map,
                                            SurveyQuestion question,
                                            LocalDateTime day) {
        var account = AuthDetail.fromMap(map);

        var ran = new Random();
        var surveyAnswer = new SurveyAnswer(ran.nextInt(question.getNumberOfAnswers()),
                UUID.fromString(question.getId()),
                "");

        surveyAnswer.setCreatedAt(day);
        surveyAnswer.setVotePercent((
                1.0 * surveyAnswer.getVote()
                        / question.getNumberOfAnswers())
                * 100.0);
        surveyAnswer.setType(question.getType());
        surveyAnswer.setOwnerId(account.getId().toString());
        surveyAnswer.setEntrepriseId(account.getEntrepriseId().toString());
        return surveyAnswer;
    }

    private Flux<LocalDateTime> toDays(LocalDateTime start) {
        return Flux.generate(() -> start, (s, sink) -> {
            sink.next(s);
            if (s.isAfter(LocalDateTime.now()))
                sink.complete();
            return s.plusDays(1);
        });
    }

    public Flux<Counts> countAverageMood(AuthDetail authDetail,
                                        UUID userId,
                                        SurveyQuestionType type,
                                        LocalDateTime start)
    {
        AtomicReference<Map<Integer, Counts>> map = new AtomicReference<>();

        map.set(Map.of(
                0, Counts.builder().status(0).data(new HashSet<>()).build(),
                1,  Counts.builder().status(1).data(new HashSet<>()).build(),
                2,  Counts.builder().status(2).data(new HashSet<>()).build(),
                3, Counts.builder().status(3).data(new HashSet<>()).build()
        ));


        return findAllInPeriod(authDetail,userId, type, start)
                .map(a -> {
                    map.get().get(findIndex(a.getVotePercent()))
                            .addMood(PeriodCount.builder().date(a.getCreatedAt().toLocalDate())
                                    .value(1).build());
                    return a;
                })
                .collectList()
//                .doOnEach(l -> log.info("list is {} and size is: {}", l.get(), l.get().size()))
                .map(l -> map.get())
                .flatMapIterable(Map::values);
//                .groupBy(a -> findIndex(a.getVotePercent()))
//                .flatMap(g ->
//                       g.map(a -> {
//                        map.get().get(g.key())
////                                .print()
//                                .addMood(PeriodCount.builder().date(a
//                                .getCreatedAt()
//                                .toLocalDate()).value(1).build());
//                        log.info("key {}",g.key());
//                        return a;
//                       })
//                )
//                .collectList()
//                .map(l -> map.get())
//                .flatMapIterable(Map::values);
    }





    public Flux<MoodCount> countMood(AuthDetail authDetail,
                                     UUID userId,
                                     SurveyQuestionType type,
                                     LocalDateTime start) {

        return findAllInPeriod(authDetail,userId, type, start)
                .groupBy(a -> a.getCreatedAt().toLocalDate())
                .flatMap(g -> {
                    var mood = MoodCount.builder()
                            .date(g.key()).build();
                    return g.map(a -> mood.addVote(VoteGroup.builder().vote(a.getVote())
                            .count(1).build())).last();
                    });

    }


    public Flux<PeriodCount> getAverageForBarGraph(AuthDetail authDetail, UUID userId, SurveyQuestionType type, LocalDateTime start) {
        return findAllInPeriod(authDetail,userId, type, start)
                .groupBy(a -> a.getCreatedAt().toLocalDate())
                .flatMap(g -> {
                    PeriodCount pc = PeriodCount.builder()
                            .date(g.key())
                            .value(0)
                            .votesNb(0)
                            .build();
                    return g.reduce(pc , (p1, p2) -> {
                        p1.increment();
                        p1.setVotesNb((int) (p1.getVotesNb() + p2.getVotePercent()));
                        return p1;
                    }).map(p->{
                        p.setValue(p.getVotesNb() / p.getValue());
                        return p;
                    });
                });
    }

    private Flux<SurveyAnswer> findAllInPeriod(
            AuthDetail authDetail, UUID userId,
            SurveyQuestionType type, LocalDateTime start) {
        if (userId == null) {
            userId = authDetail.getEntrepriseId();
            log.info("userId is null, using entrepriseId {}", userId);
        }
        if (!authDetail.isContaingRole("Entreprise_admin"))
            userId = authDetail.getId();

        if (type == null)
           return surveyAnswerRepository.findAllByEntrepriseIdAndCreatedAtBetween(userId.toString(),start,
                    start.plusMonths(1));
        else
           return  surveyAnswerRepository.findAllByEntrepriseIdAndTypeAndCreatedAtBetween(userId.toString(),
                   type,start,
                    start.plusMonths(1));
    }
    private int findIndex(double percent)
    {
        if (percent < 25)
            return 0;
        if (percent < 50)
            return 1;
        if (percent < 75)
            return 2;
        return 3;
    }

    public Flux<AuthDetail> getVoterAtADay(AuthDetail authDetail, LocalDateTime date,
                                           Integer status,
                                           SurveyQuestionType type) {
        if (status < 0 || status > 3)
            return Flux.error(new IllegalArgumentException("Status must be between 0 and 3"));
        var start = date.withSecond(0).withNano(0).withMinute(0).withHour(0);
        var end = start.plusDays(1);
        var min = status * 25;
        var max = min + 25;
            return surveyAnswerRepository.findAllVotersInAday(authDetail.getEntrepriseId().toString(),
                    start, end,
                    min, max,
                    type
                    ).groupBy(SurveyAnswer::getOwnerId)
                    .map(GroupedFlux::key)
                    .collectList()
                    .map(l -> l.stream().map(UUID::fromString).collect(Collectors.toSet()))
                    .flatMapMany(fusionAuthService::retrieveBulkUsers);
    }
}