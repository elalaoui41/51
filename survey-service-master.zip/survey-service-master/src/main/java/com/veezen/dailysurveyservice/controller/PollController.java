package com.veezen.dailysurveyservice.controller;

import com.veezen.dailysurveyservice.model.AuthDetail;
import com.veezen.dailysurveyservice.model.Poll;
import com.veezen.dailysurveyservice.service.PollService;
import lombok.AllArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/poll")
@AllArgsConstructor
public class PollController {
    private final PollService pollService;

    @PostMapping("/create")
    public Mono<Poll> create(Authentication authentication,
                             @RequestBody Poll poll)
    {
        var authDetail = (AuthDetail) authentication.getPrincipal();
        return pollService.create(authDetail, poll);
    }

    @PostMapping("/vote/{poll_id}/{option_id}")
    public Mono<Poll> vote(@PathVariable("poll_id") String id,
                           @PathVariable("option_id") String opetionId,
                           Authentication authentication)

    {
        var authDetail = (AuthDetail) authentication.getPrincipal();
        return pollService.vote(id, opetionId, authDetail);
    }

    @GetMapping("/last")
    public Mono<Poll> getLastPoll(Authentication authentication)
    {
        var authDetail = (AuthDetail) authentication.getPrincipal();
        return pollService.getLastPoll(authDetail);
    }
    @PostMapping("/close/{poll_id}")
    public Mono<Poll> endPoll(@PathVariable("poll_id") String id,
                              Authentication authentication)
    {
        var authDetail = (AuthDetail) authentication.getPrincipal();
        return pollService.endPoll(id, authDetail);
    }
}
