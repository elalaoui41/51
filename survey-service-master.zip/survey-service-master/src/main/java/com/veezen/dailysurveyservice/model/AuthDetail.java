package com.veezen.dailysurveyservice.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import java.util.Map;
import java.util.Set;
import java.util.UUID;

@Data
@Builder
@AllArgsConstructor
public class AuthDetail {
    private UUID id;
    private String token;
    private UUID entrepriseId;
    private String avatarUrl;
    private String fullName;
    private String userName;
    private Set<String > roles;
    private double averageMood;

    public boolean isContaingRole(String role) {
        return roles.contains(role);
    }
    public boolean isContainingRoles(Set<String> roles) {
        return this.roles.containsAll(roles);
    }

    public boolean isContainingAnyRole(Set<String> roles) {
        return roles.stream().anyMatch(this.roles::contains);
    }
   /*
   *
   * {
    "@type": "Employee",
    "userName": "veezenAdmin",
    "passowrd": "bone123123",
    "email": "veezen@veezen.com",
    "firstName": "veezen",
    "lastName": "veezen",
    "phoneNumber": "+21268946821",
    "city": null,
    "country": "Morroco",
    "street": "so",
    "zipCode": "20100",
    "coverImageUrl": "",
    "avatar": "https://res.cloudinary.com/veezen/image/upload/v1655596044/bnivbnm7s73mukhjpwkt.png",
    "entrepriseId": "712c7869-19a1-41ed-96f9-b74ca02d15af",
    "id": "af32a271-b7c3-46f1-9abf-34ec8cd934df",
    "fullName": "veezen veezen",
    "passwordChangeRequired": null,
    "user": null
}
   * */

    public static AuthDetail fromMap(Map map)
    {
        return AuthDetail.builder()
                .id(UUID.fromString((String) map.get("id")))
                .entrepriseId(UUID.fromString((String) map.get("entrepriseId")))
                .avatarUrl((String) map.get("avatar"))
                .fullName((String) map.get("firstName") + " " + map.get("lastName"))
                .userName((String) map.get("userName"))
                .build();
    }
}
