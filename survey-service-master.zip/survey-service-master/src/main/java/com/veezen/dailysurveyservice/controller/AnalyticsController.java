package com.veezen.dailysurveyservice.controller;

import com.veezen.dailysurveyservice.model.*;
import com.veezen.dailysurveyservice.service.SurveyAnalyticsSerice;
import lombok.AllArgsConstructor;
import org.springframework.boot.context.properties.bind.DefaultValue;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.MediaType;
import org.springframework.lang.Nullable;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/analytics")
@AllArgsConstructor
public class AnalyticsController {
    private final SurveyAnalyticsSerice surveyAnalyticsSerice;


    @GetMapping("/voters")
    public Flux<AuthDetail> getVoters(@RequestParam("date")
                                          @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
                                          LocalDateTime date,
                                      Authentication authentication,
                                      @RequestParam("status")  Integer status,
                                      @RequestParam("type")SurveyQuestionType type) {
        var authDetail = (com.veezen.dailysurveyservice.model.AuthDetail) authentication.getPrincipal();
        return surveyAnalyticsSerice.getVoterAtADay(authDetail, date, status,type);

    }

    @PostMapping(value = "/create/random/data",produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public Flux<Map> createRandomData(Authentication authentication)
    {
        var authDetail = (com.veezen.dailysurveyservice.model.AuthDetail)
                authentication.getPrincipal();
        return surveyAnalyticsSerice.createRandomAnswers(authDetail);
    }
    @GetMapping("/average")
    public Flux<Counts> getAverage(Authentication authentication,
                                  @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
                                  @RequestParam("start")
                                  LocalDateTime start,
                                   @Nullable @RequestParam("userId") UUID userId,
                                   @Nullable @RequestParam("type")SurveyQuestionType type)
    {
        var authDetail = (com.veezen.dailysurveyservice.model.AuthDetail) authentication.getPrincipal();

        return surveyAnalyticsSerice.countAverageMood(authDetail,
                userId,
                type,
                start);
    }


    @GetMapping("/mood")
    public Flux<MoodCount> getMood(Authentication authentication,
                                   @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
                                   @RequestParam("start")
                                   LocalDateTime start,
                                   @Nullable @RequestParam("userId") UUID userId,
                                   @Nullable @RequestParam("type")SurveyQuestionType type)
    {
        var authDetail = (com.veezen.dailysurveyservice.model.AuthDetail) authentication.getPrincipal();

        return surveyAnalyticsSerice.countMood(authDetail,
                userId,
                type,
                start);
    }

//
    @GetMapping("/bar")
    public Flux<PeriodCount> getAverageBar(Authentication authentication,
                                             @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
                                             @RequestParam("start")
                                             LocalDateTime start,
                                             @Nullable @RequestParam("userId") UUID userId,
                                            @Nullable @RequestParam("type")SurveyQuestionType type)
    {
        var authDetail = (com.veezen.dailysurveyservice.model.AuthDetail) authentication.getPrincipal();

        return surveyAnalyticsSerice.getAverageForBarGraph(authDetail,
                userId,
                type,
                start);
    }


}
