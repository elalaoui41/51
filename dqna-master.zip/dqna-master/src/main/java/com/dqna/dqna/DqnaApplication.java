package com.dqna.dqna;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class DqnaApplication {

    public static void main(String[] args) {
        SpringApplication.run(DqnaApplication.class, args);
    }

}


