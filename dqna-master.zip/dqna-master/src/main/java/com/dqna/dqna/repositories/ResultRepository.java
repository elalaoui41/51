package com.dqna.dqna.repositories;

import com.dqna.dqna.entities.ResultEntity;
import org.springframework.data.neo4j.repository.Neo4jRepository;
import org.springframework.data.neo4j.repository.query.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface ResultRepository extends Neo4jRepository<ResultEntity, UUID> {
    ResultEntity findOneByResult(String result);
    ResultEntity findOneById(UUID id);
    @Query("match (:Answer{id:$id})-[:Result_Is]->(results) return results")
    List<ResultEntity> findResultsByAnswerId(@Param("id") String id);
}
