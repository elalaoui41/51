package com.dqna.dqna.controllers;

import com.dqna.dqna.entities.QuestionEntity;
import com.dqna.dqna.repositories.QuestionRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/questions")
public class QuestionController {

    private final QuestionRepository qr;

    public QuestionController(QuestionRepository qr) {
        this.qr = qr;
    }

    @PutMapping
    QuestionEntity createOrUpdateQuestion(@RequestBody QuestionEntity newQ){
        return qr.save(newQ);
    }

    @GetMapping
    List<QuestionEntity> getQuestions(){
        return qr.findAll();
    }

    @GetMapping("/by-question")
    QuestionEntity getByQuestion(@RequestParam String question)
    {
        return qr.findOneByQuestion(question);
    }

    @GetMapping("/by-answer/{answerId}")
    QuestionEntity getByAnswer(@PathVariable String answerId)
    {
        return qr.findOneByAnswerId(answerId);
    }

    @DeleteMapping("/{id}")
    void deleteById(@PathVariable String id)
    {
        qr.deleteById(UUID.fromString(id));
    }


    @GetMapping("/{id}")
    QuestionEntity getQuestionById(@PathVariable String id)
    {
        return qr.findOneById(UUID.fromString(id));
    }

}
