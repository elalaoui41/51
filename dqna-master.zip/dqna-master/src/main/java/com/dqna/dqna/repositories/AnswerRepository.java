package com.dqna.dqna.repositories;

import com.dqna.dqna.entities.AnswerEntity;
import org.springframework.data.neo4j.repository.Neo4jRepository;
import org.springframework.data.neo4j.repository.query.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface AnswerRepository extends Neo4jRepository<AnswerEntity, UUID> {
    AnswerEntity findOneByAnswer(String answer);
    AnswerEntity findOneById(UUID id);
    @Query("MATCH (:Question{id:$id})-[:Answer_Is]->(answers) RETURN answers")
    List<AnswerEntity> findAnswersByQuestionId(@Param("id") String questionId);
}
