package com.dqna.dqna.controllers;


import com.dqna.dqna.entities.ResultEntity;
import com.dqna.dqna.repositories.ResultRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/results")
public class ResultController {

    private final ResultRepository rr;

    public ResultController(ResultRepository rr) {
        this.rr = rr;
    }

    @GetMapping
    List<ResultEntity> getResults(){
        return rr.findAll();
    }

    @PutMapping
    ResultEntity createOrUpdateResult(@RequestBody ResultEntity newR){
        return rr.save(newR);
    }

    @GetMapping("/by-result")
    ResultEntity getByResult(@RequestParam String result)
    {
        return rr.findOneByResult(result);
    }

    @GetMapping("/by-answer/{id}")
    List<ResultEntity> getResultsByAnswerId(@PathVariable String id)
    {
        return rr.findResultsByAnswerId(id);
    }

    @DeleteMapping("/{id}")
    void deleteById(@PathVariable String id)
    {
        rr.deleteById(UUID.fromString(id));
    }

    @GetMapping("/{id}")
    ResultEntity getResultById(@PathVariable String id)
    {
        return rr.findOneById(UUID.fromString(id));
    }
}
