package com.dqna.dqna.entities;

public enum Type {
    IMAGE,
    INPUT,
    INPUT_DATE,
    TEXT,
    MESSAGE,
    BUTTON
}
