package com.dqna.dqna.controllers;

import com.dqna.dqna.entities.AnswerEntity;
import com.dqna.dqna.repositories.AnswerRepository;
import com.dqna.dqna.repositories.QuestionRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/answers")
public class AnswerController {

    private final AnswerRepository ar;
    private final QuestionRepository qr;

    public AnswerController(AnswerRepository ar, QuestionRepository qr) {
        this.ar = ar;
        this.qr = qr;
    }

    @PutMapping
    AnswerEntity createOrUpdateAnswer(@RequestBody AnswerEntity newA){
        return ar.save(newA);
    }

    @GetMapping
    List<AnswerEntity> getAnswers(){
        return ar.findAll();
    }

    @GetMapping("/by-answer")
    AnswerEntity getByAnswer(@RequestParam String answer)
    {
        return ar.findOneByAnswer(answer);
    }

    @GetMapping("/by-question/{questionId}")
    List<AnswerEntity> getAnswersByQuestionId(@PathVariable String questionId)
    {
        return ar.findAnswersByQuestionId(questionId);
    }
    @GetMapping("link")
    AnswerEntity linkAnswerToQuestion(@RequestParam String answerId, @RequestParam String qId)
    {
        var q = qr.findOneById(UUID.fromString(qId));
        var a = ar.findOneById(UUID.fromString(answerId));
        a.getQuestions().add(q);
        return ar.save(a);
    }
    @DeleteMapping("/{id}")
    void deleteById(@PathVariable String id)
    {
        ar.deleteById(UUID.fromString(id));
    }

    @GetMapping("/{id}")
    AnswerEntity getAnswerById(@PathVariable String id)
    {
        return ar.findOneById(UUID.fromString(id));
    }
}