package com.dqna.dqna.controllers;

import com.dqna.dqna.entities.TranslationEntity;
import com.dqna.dqna.repositories.TranslationRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/translations")
public class TranslationController {

    private final TranslationRepository tr;

    public TranslationController(TranslationRepository tr) {
        this.tr = tr;
    }

    @GetMapping
    List<TranslationEntity> getTranslations(){
        return tr.findAll();
    }

    @PutMapping
    TranslationEntity createOrUpdateTranslation(@RequestBody TranslationEntity newT){
        return tr.save(newT);
    }

    @GetMapping("/by-translation")
    TranslationEntity getByTranslation(@RequestParam String translation)
    {
        return tr.findOneByTranslation(translation);
    }

    @GetMapping("/by-question/{id}")
    List<TranslationEntity> getTranslationsByQuestionId(@PathVariable String id)
    {
        return tr.findTranslationsByQuestionId(id);
    }

    @GetMapping("/by-answer/{id}")
    List<TranslationEntity> getTranslationsByAnswerId(@PathVariable String id)
    {
        return tr.findTranslationsByAnswerId(id);
    }

    @GetMapping("/by-result/{id}")
    List<TranslationEntity> getTranslationsByResultId(@PathVariable String id)
    {
        return tr.findTranslationsByResultId(id);
    }

    @DeleteMapping("/{id}")
    void deleteById(@PathVariable String id)
    {
        tr.deleteById(UUID.fromString(id));
    }

    @GetMapping("/{id}")
    TranslationEntity getTranslationById(@PathVariable String id)
    {
        return tr.findOneById(UUID.fromString(id));
    }
}
