package com.dqna.dqna.entities;

import org.springframework.data.neo4j.core.schema.GeneratedValue;
import org.springframework.data.neo4j.core.schema.Id;
import org.springframework.data.neo4j.core.schema.Node;
import org.springframework.data.neo4j.core.schema.Relationship;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

@Node("Result")
public class ResultEntity {

    @Id @GeneratedValue
    private UUID id;

    private String result;

    @Relationship(type = "Next_Question_From_Result", direction = Relationship.Direction.OUTGOING)
    private Set<QuestionEntity> questions = new HashSet<>();

    @Relationship(type = "Translation_Is", direction = Relationship.Direction.OUTGOING)
    private Set<TranslationEntity> translations = new HashSet<>();

    public ResultEntity(String result) {
        this.result = result;
    }
    public ResultEntity() {}

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public Set<TranslationEntity> getTranslations() {
        return translations;
    }

    public void setTranslations(Set<TranslationEntity> translations) {
        this.translations = translations;
    }

    public Set<QuestionEntity> getQuestions() {
        return questions;
    }

    public void setQuestions(Set<QuestionEntity> questions) {
        this.questions = questions;
    }
}
