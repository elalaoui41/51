package com.dqna.dqna.entities;

import com.fasterxml.jackson.annotation.JsonProperty;
import org.springframework.data.neo4j.core.schema.GeneratedValue;
import org.springframework.data.neo4j.core.schema.Id;
import org.springframework.data.neo4j.core.schema.Node;
import org.springframework.data.neo4j.core.schema.Relationship;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

@Node("Answer")
public class AnswerEntity {

    @Id @GeneratedValue
    private UUID id;
    private Type type;
    private int score;
    private String imageURl;
    private String answer;

    @Relationship(type = "Next_Question_From_Answer", direction = Relationship.Direction.OUTGOING)
    private Set<QuestionEntity> questions = new HashSet<>();

    @Relationship(type = "Result_Is", direction =  Relationship.Direction.OUTGOING)
    private Set<ResultEntity> results = new HashSet<>();

    @Relationship(type = "Translation_Is", direction = Relationship.Direction.OUTGOING)
    private Set<TranslationEntity> translations = new HashSet<>();

    public AnswerEntity(){}

    public AnswerEntity(@JsonProperty("answer") String answer,
                        @JsonProperty("score") int score,
                        @JsonProperty("imageURl") String imageURl) {
        this.answer = answer;
        this.score = score;
        this.imageURl = imageURl;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public Set<QuestionEntity> getQuestions() {
        return questions;
    }

    public void setQuestions(Set<QuestionEntity> questions) {
        this.questions = questions;
    }

    public Set<TranslationEntity> getTranslations() {
        return translations;
    }

    public void setTranslations(Set<TranslationEntity> translations) {
        this.translations = translations;
    }

    public Set<ResultEntity> getResults() {
        return results;
    }

    public void setResults(Set<ResultEntity> results) {
        this.results = results;
    }

    public Type getType() {
        return type;
    }

    public void setType(Type type) {
        this.type = type;
    }

    public String getImageURl() {
        return imageURl;
    }

    public void setImageURl(String imageURl) {
        this.imageURl = imageURl;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }
}
