package com.dqna.dqna.repositories;

import com.dqna.dqna.entities.TranslationEntity;
import org.springframework.data.neo4j.repository.Neo4jRepository;
import org.springframework.data.neo4j.repository.query.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface TranslationRepository extends Neo4jRepository<TranslationEntity, UUID> {
    TranslationEntity findOneByTranslation(String result);
    TranslationEntity findOneById(UUID id);
    @Query("MATCH (:Question{id:$id})-[:Translation_Is]->(translations) RETURN translations")
    List<TranslationEntity> findTranslationsByQuestionId(@Param("id") String questionId);

    @Query("MATCH (:Answer{id:$id})-[:Translation_Is]->(translations) RETURN translations")
    List<TranslationEntity> findTranslationsByAnswerId(@Param("id") String AnswerId);

    @Query("MATCH (:Result{id:$id})-[:Translation_Is]->(translations) RETURN translations")
    List<TranslationEntity> findTranslationsByResultId(@Param("id") String resultId);
}
