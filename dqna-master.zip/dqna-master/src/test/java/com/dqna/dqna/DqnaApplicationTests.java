package com.dqna.dqna;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DqnaApplicationTests {

    @Test
    void contextLoads() {
    }

}
