package com.wikayti.result.service;

import com.wikayti.result.model.AnswerEntity;
import com.wikayti.result.model.QuestionEntity;
import com.wikayti.result.model.Test;
import lombok.AllArgsConstructor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.*;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

@Service
@AllArgsConstructor
public class ExportService {
    public QuestionService questionService;
    public TestService testService;

    public Mono<Resource> export() {

        return testService.findAll()
                .collectList()
                .flatMap(list -> this.testsToRow(list))
                .flatMap(file -> Mono.fromCallable(() -> {
                    try {
                        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                        file.write(outputStream);
                        return new ByteArrayInputStream(outputStream.toByteArray());
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }

                }).subscribeOn(Schedulers.boundedElastic()))
                .flatMap(x -> {
                    Resource resource = new InputStreamResource(x);
                    return Mono.just(resource);
                });
    }

    private Mono<Workbook> testsToRow(List<Test> tests) {
        XSSFWorkbook workbook;


        workbook = new XSSFWorkbook();
        XSSFSheet sheet;
        AtomicInteger index = new AtomicInteger();
        HashMap<Integer, Integer> indexes = new HashMap<>();
        HashMap<Integer, Integer> aIndex = new HashMap<>();
        HashMap<Integer, AnswerEntity> previosAnswer = new HashMap<>();
        sheet = workbook.createSheet("data");
        AtomicReference<XSSFRow> row =  new AtomicReference<>();
        CellStyle style = workbook.createCellStyle();
        XSSFFont font = workbook.createFont();
        font.setBold(true);
        font.setFontHeight(16);
        style.setFont(font);
        return Flux.fromStream(tests.stream())
                .flatMap(test1 -> {
                    int i = index.get();
                    row.set(sheet.createRow(index.get()));
                    indexes.put(index.get(),0);
                    index.getAndIncrement();
                    aIndex.put(i, 0);
                    return Flux.fromStream(test1.getAnswers().stream())
                            .flatMap(a->{
                                previosAnswer.put(aIndex.get(i), a);
                                aIndex.put(i, aIndex.get(i) + 1);
                                int cell  = indexes.get(i);
                                indexes.put(i, cell + 2);
                                if (cell == 0) {
                                    System.out.println("index 0");
                            return         this.addAnswer(a,
                                                    questionService
                                                            .getQuestionByAnserId("416311ef-5a34-41cb-9276-d91a042b1027")
                                                    , row.get(), cell);
                                } else {

                                   return  this.addAnswer(a,
                                            questionService
                                                    .getQuestionByAnserId(previosAnswer.get(aIndex.get(i) -1).getId().toString())
                                            , row.get(), cell);
                                }
                            });
                })
                .collectList()
                .map(a->workbook);
    }

    /**
     row = sheet.createRow(index);

     cellIndex = 0;
     System.out.println(test.getAnswers().size());
     for (int i = 0; i < test.getAnswers().size(); i++) {
     if (cellIndex == 0) {
     System.out.println("index 0");
     this.addAnswer(test.getAnswers().get(i),
     questionService
     .getQuestionByAnserId("416311ef-5a34-41cb-9276-d91a042b1027")
     , row, cellIndex)
     .subscribe(System.out::println);
     } else {
     System.out.println("index " + cellIndex);
     this.addAnswer(test.getAnswers().get(i),
     questionService
     .getQuestionByAnserId(test.getAnswers().get(i - 1).getId().toString())
     , row, cellIndex).subscribe(System.out::println);
     }

     cellIndex += 2;
     }
     index++;
     }}
     * */
    private Mono<String> addAnswer(AnswerEntity a, Mono<QuestionEntity> question, XSSFRow row, int cellIndex) {

        return question.map(q -> {
            XSSFCell cell = row.createCell(cellIndex);
            cell.setCellValue(q.getQuestion());
            XSSFCell cell2 = row.createCell(cellIndex + 1);
            cell2.setCellValue(a.getAnswer());
            System.out.println(a.getAnswer());
            return q;
        }).map(QuestionEntity::getQuestion);
    }
}
