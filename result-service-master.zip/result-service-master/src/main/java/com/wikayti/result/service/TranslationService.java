package com.wikayti.result.service;

import com.wikayti.result.model.TranslationEntity;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;

import java.util.UUID;

@Service
public class TranslationService {
    private final WebClient client;

    public TranslationService(@Value("${wikayti.qna.uri}") String qnaUri) {
        this.client = WebClient.create(qnaUri);
    }
    public Flux<TranslationEntity> findByQuestionId(UUID qId)
    {
        return client.get().uri("/translations/by-question/" + qId.toString())
                .retrieve().bodyToFlux(TranslationEntity.class);
    }
    public Flux<TranslationEntity> findOneByAnswerId(UUID aId)
    {
        return client.get().uri("/translations/by-answer/" + aId.toString())
                .retrieve().bodyToFlux(TranslationEntity.class);
    }
}
