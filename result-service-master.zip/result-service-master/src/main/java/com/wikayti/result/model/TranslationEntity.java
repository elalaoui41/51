package com.wikayti.result.model;


import java.util.UUID;


public class TranslationEntity {

    private UUID id;

    private String language;
    private String translation;


    public TranslationEntity(String language) {
        this.language = language;
    }

    public TranslationEntity() {}

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getTranslation() {
        return translation;
    }

    public void setTranslation(String translation) {
        this.translation = translation;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}
