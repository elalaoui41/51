package com.wikayti.result.dao;

import com.wikayti.result.model.Test;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import reactor.core.publisher.Flux;

public interface TestRepository extends ReactiveMongoRepository<Test, String> {
    Flux<Test> findAllByClientIdOrderByCreatedAtDesc(String clientId);

}
