package com.wikayti.result.controller;

import com.wikayti.result.model.AnswerEntity;
import com.wikayti.result.model.QuestionEntity;
import com.wikayti.result.service.ExportService;
import com.wikayti.result.service.QuestionService;
import lombok.AllArgsConstructor;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.LocalDate;

@RestController
@RequestMapping("questions")
@CrossOrigin("*")
@AllArgsConstructor
public class QuestionController {
    private final QuestionService questionService;
    private final ExportService exportService;

    @GetMapping("start")
    public Mono<QuestionEntity> start(@RequestParam(defaultValue = "fr", value = "lang") String lang)
    {
        return questionService.start(lang);
    }

    @GetMapping("next/{answerId}")
    public Mono<QuestionEntity> next(@RequestParam(defaultValue = "fr", value = "lang") String lang, @PathVariable("answerId") String aId)
    {
        return questionService.next(aId,lang);
    }

    @GetMapping("link")
    public Mono<String> link(@RequestParam("pAnswer") String qId, @RequestParam("q2") String q2)
    {
        return  questionService.link(qId, q2);
    }
    @GetMapping("export")
    public ResponseEntity<Mono<Resource>> export()
    {
        String fileName = String.format("veezen_data_%s.XLSX", LocalDate.now());
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION,  "attachment; filename=" + fileName)
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_OCTET_STREAM_VALUE)
                .body(exportService.export());
    }
}
