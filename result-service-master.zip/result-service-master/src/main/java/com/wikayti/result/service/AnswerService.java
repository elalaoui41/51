package com.wikayti.result.service;

import com.wikayti.result.model.AnswerEntity;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;

import java.util.UUID;

@Service
public class AnswerService {
    private final WebClient client;

    public AnswerService(@Value("${wikayti.qna.uri}") String qnaUri) {
        this.client = WebClient.create(qnaUri);
    }

    public Flux<AnswerEntity> findAllbyQuestionId(UUID id)
    {
        return client.get().uri("/answers/by-question/" + id.toString())
                .retrieve().bodyToFlux(AnswerEntity.class);
    }
}
