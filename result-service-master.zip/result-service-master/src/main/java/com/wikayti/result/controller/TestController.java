package com.wikayti.result.controller;

import com.wikayti.result.model.ResultEntity;
import com.wikayti.result.model.Test;
import com.wikayti.result.service.TestService;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("test")
@CrossOrigin("*")
@AllArgsConstructor
public class TestController {
    private final TestService testService;
    @PostMapping("create")
    public Mono<Test> create(
            @RequestBody Test test,
                             @RequestParam(value = "lang", defaultValue = "fr") String lang)
    {
        return testService.create(test, lang);
    }

    @PostMapping("result")
    public Mono<ResultEntity> create(
            @RequestBody ResultEntity result)
    {
        return testService.create(result);
    }

//    @GetMapping("me")
//    public Flux<Test> getAllMyTests(@RequestParam(value = "lang", defaultValue = "fr") String lang)
//    {
//        return testService.findAllMyTests( (Account) authentication.getCredentials(),lang);
//    }
}

