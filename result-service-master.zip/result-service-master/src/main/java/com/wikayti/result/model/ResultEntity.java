package com.wikayti.result.model;



import java.util.HashSet;
import java.util.Set;
import java.util.UUID;


public class ResultEntity {


    private UUID id;

    private String result;
   private int score;


    private Set<QuestionEntity> questions = new HashSet<>();


    private Set<TranslationEntity> translations = new HashSet<>();

    public ResultEntity(String result, int score) {
        this.result = result;
        this.score = score;
    }
    public ResultEntity() {}

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public Set<TranslationEntity> getTranslations() {
        return translations;
    }

    public void setTranslations(Set<TranslationEntity> translations) {
        this.translations = translations;
    }

    public Set<QuestionEntity> getQuestions() {
        return questions;
    }

    public void setQuestions(Set<QuestionEntity> questions) {
        this.questions = questions;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }
}
