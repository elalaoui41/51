package com.wikayti.result.service;

import com.wikayti.result.dao.ResultRepository;
import com.wikayti.result.dao.TestRepository;
import com.wikayti.result.model.AnswerEntity;
import com.wikayti.result.model.ResultEntity;
import com.wikayti.result.model.Test;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.UUID;

@Service
@AllArgsConstructor
@Slf4j
public class TestService {
    private final TestRepository testRepository;
    private final ResultRepository resultRepository;


    public Mono<Test> create(Test test, String lang)
    {
        return Mono.just(test.getAnswers())
                .map(this::getResult)
                .flatMap(testRepository::save);
    }

    private Test getResult(List<AnswerEntity> answerEntities) {
        int finalScore = -1;
        Test test = new Test();
        for (AnswerEntity answerEntity : answerEntities) {
            if (answerEntity.getScore() >= 0)
            {
                if (finalScore == -1)
                    finalScore = 0;
                finalScore += answerEntity.getScore();
            }
        }

        if (finalScore >= 0)
        {
            test.setResult(new ResultEntity(String.format("score = %d", finalScore), finalScore));
            test.getResult().setId(UUID.randomUUID());
        }else
            test.setResult(new ResultEntity("Excellente journée! \uD83D\uDC4B", finalScore));
        test.setAnswers(answerEntities);
        return test;
    }

    public Mono<ResultEntity> create(ResultEntity result)
    {
        return resultRepository.save(result);
    }

    public Flux<Test> findAll()
    {
        return testRepository.findAll();
    }
    public Flux<ResultEntity> getAllResults()
    {
        return resultRepository.findAll();
    }

//    public Flux<Test> findAllMyTests( String lang)
//    {
//        return testRepository.findAllByClientIdOrderByCreatedAtDesc(account.getId())
//                .map(t-> setLang(t, lang));
//    }

//    private Test setLang(Test t, String lang) {
////        t.getResult().setResult(t.getResult().getTranslations().(lang));
//        return t;
//    }
}
