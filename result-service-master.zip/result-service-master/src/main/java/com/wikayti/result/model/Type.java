package com.wikayti.result.model;

public enum Type {
    IMAGE,
    INPUT,
    INPUT_DATE,
    TEXT,
    MESSAGE,
    BUTTON
}
