package com.wikayti.result.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDate;
import java.util.List;
import java.util.Set;

@Document(collection = "veezen_test")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Test {

    @Id
    private String id;
    private List<AnswerEntity> answers;
    private ResultEntity result;
    private String clientId;
    private LocalDate createdAt;

    @JsonCreator
    public Test(@JsonProperty("answers") List<AnswerEntity> answers) {
        this.answers = answers;
        this.createdAt = LocalDate.now();
    }
}
