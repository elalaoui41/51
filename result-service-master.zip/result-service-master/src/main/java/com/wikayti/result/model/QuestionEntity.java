package com.wikayti.result.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;


public class QuestionEntity {


    private UUID id;

    private String question;

    private String imageUrl;

    private Type type;
    private String soundData;



    private Set<AnswerEntity> answers = new HashSet<>();


    private Set<TranslationEntity> translations = new HashSet<>();

    public QuestionEntity(){}

    public QuestionEntity(@JsonProperty("question") String question,
                          @JsonProperty("type")Type type,
                          @JsonProperty("imageUrl")String imageUrl) {
        this.question = question;
        this.type = type;
        this.imageUrl = imageUrl;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public Set<AnswerEntity> getAnswers() {
        return answers;
    }

    public void setAnswers(Set<AnswerEntity> answers) {
        this.answers = answers;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }



    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }


    public String getSoundData() {
        return soundData;
    }

    public void setSoundData(String soundData) {
        this.soundData = soundData;
    }

    public Set<TranslationEntity> getTranslations() {
        return translations;
    }

    public void setTranslations(Set<TranslationEntity> translations) {
        this.translations = translations;
    }

    public Type getType() {
        return type;
    }

    public void setType(Type type) {
        this.type = type;
    }
}
