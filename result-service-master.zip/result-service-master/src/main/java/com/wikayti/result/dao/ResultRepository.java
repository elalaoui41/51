package com.wikayti.result.dao;

import com.wikayti.result.model.ResultEntity;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;

public interface ResultRepository extends ReactiveMongoRepository<ResultEntity, String> {
}
