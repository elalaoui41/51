package com.wikayti.result.service;

import com.wikayti.result.config.EndException;
import com.wikayti.result.model.AnswerEntity;
import com.wikayti.result.model.QuestionEntity;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Set;

@Service
public class QuestionService {
    private final WebClient client;
    private final TranslationService translationService;
    private final AnswerService answerService;

    public QuestionService(@Value("${wikayti.qna.uri}") String qnaUri, TranslationService translationService, AnswerService answerService) {
        this.client = WebClient.create(qnaUri);
        this.translationService = translationService;
        this.answerService = answerService;
    }

    public Mono<QuestionEntity> start(String lang)
    {
        return next("416311ef-5a34-41cb-9276-d91a042b1027", lang);
    }

    public Mono<QuestionEntity> next(String answerId, String lang)
    {
        return client.get().uri("/questions/by-answer/" + answerId)
                .retrieve().bodyToMono(QuestionEntity.class)
                .flatMap(q-> injectAnswers(q, lang))
                .flatMap(q-> this.injectTranslation(q, lang))
                .switchIfEmpty(Mono.error(new EndException()));
    }
    public Mono<QuestionEntity> getQuestionByAnserId(String answerId)
    {
        return client.get().uri("/questions/by-answer/" + answerId)
                .retrieve().bodyToMono(QuestionEntity.class);
    }
    private Mono<QuestionEntity> injectTranslation(QuestionEntity q, String lang) {
        if (lang.equals("ar"))
        {
            return translationService.findByQuestionId(q.getId())
                    .collectList()
                    .map(t->{
                        q.setQuestion(t.get(0).getTranslation());
                        return q;
                    });

        }
        return Mono.just(q);
    }

    private Mono<QuestionEntity> injectAnswers(QuestionEntity q,String lang) {
        if (lang.equals("ar"))
            return answerService.findAllbyQuestionId(q.getId())
                    .flatMap(this::injectTranslationIntoAnswer)
                    .collectList()
                    .map(list-> {
                        q.setAnswers(Set.copyOf(list));
                        return q;
                    });
        return answerService.findAllbyQuestionId(q.getId())
                .collectList()
                .map(list-> {
                    q.setAnswers(Set.copyOf(list));
                    return q;
                });
    }

    private Mono<AnswerEntity> injectTranslationIntoAnswer(AnswerEntity a) {
        return translationService.findOneByAnswerId(a.getId())
                .collectList()
                .map(t-> {
                    a.setAnswer(t.get(0).getTranslation());
                    return a;
                });
    }
    public Mono<Void> linkToNextQuestion(AnswerEntity answerEntity, String next)
    {
        return      client.get().uri(String.format("answers/link?answerId=%s&qId=%s",answerEntity.getId(),next))
                .retrieve()
                .toBodilessEntity()
                .then();
    }

    public Mono<String> link(String qId, String q2) {

        return Mono.just("start")
                .doOnSuccess(s->{
                    next(qId, "fr")
                            .map(QuestionEntity::getAnswers)
                            .map(li->{
                                li.forEach(answerEntity -> {
                                linkToNextQuestion(answerEntity,q2)
                                        .subscribe();
                                });
                                return li;
                            })
                            .subscribe(System.out::println);
                });


    }
}
