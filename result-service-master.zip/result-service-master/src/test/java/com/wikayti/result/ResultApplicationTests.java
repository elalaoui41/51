package com.wikayti.result;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResultApplicationTests {

	@Test
	void contextLoads() {
	}

}
