#!/bin/sh

echo "some@gmail.com" | streamlit run /app/app.py