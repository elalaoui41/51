package com.veezen.accountservice.service;

import com.veezen.accountservice.dao.EmployeeRepository;
import com.veezen.accountservice.dao.EntrepriseRepository;
import com.veezen.accountservice.dao.VeeUserRepository;
import com.veezen.accountservice.exceptions.NotFoundException;
import com.veezen.accountservice.model.AuthDetail;
import com.veezen.accountservice.model.Entreprise;
import com.veezen.accountservice.model.VeeUser;
import org.apache.commons.lang3.NotImplementedException;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.util.Objects;

@Service("EntrepriseService")
public class EntrepriseService extends VeeUserService {
    private final EntrepriseRepository veeUserRepository;
    private final EmployeeRepository employeeRepository;



    protected EntrepriseService(FusionAuthService fusionAuthService,
                                EmployeeRepository employeeRepository,
                                EntrepriseRepository veeUserRepository) {
        super(veeUserRepository, fusionAuthService);
        this.veeUserRepository = veeUserRepository;
        this.employeeRepository = employeeRepository;
    }

    @Override
    public Mono<? extends VeeUser> create(VeeUser user) {
        return Mono.error(new NotImplementedException("UnAuthorized"));
    }

    @Override
    public Mono<? extends VeeUser> update(VeeUser old, VeeUser user) {
        return null;
    }

    @Override
    public Mono<? extends VeeUser> getOneById(String id) {
        return veeUserRepository.findById(id);
    }

    @Override
    boolean canHandle(VeeUser user) {
        return user.getClass().equals(Entreprise.class);
    }

    @Override
    boolean canHandle(Class<? extends VeeUser> user) {
        return false;
    }

    @Override
    Mono<Boolean> canHandle(String id) {
        return veeUserRepository.existsById(id);
    }

    @Override
    public Mono<Boolean> checkOpenRegistration() {
        return Mono.just(false);
    }

    @Override
    public Mono<? extends VeeUser> register(AuthDetail authDetail, VeeUser veeUser) {
        if (!authDetail.isContaingRole("Admin"))
            return Mono.error(new IllegalArgumentException("only admin can register entreprise"));

        return Mono.just(veeUser)
                .filter(veeUser1 -> veeUser1.getUser() !=  null)
                .switchIfEmpty(Mono.error(new NotFoundException("you must create and admin first")))
                .flatMap(u->
                     EmployeeService.registerUser(fusionAuthService,
                            u.getUser(),
                            employeeRepository)
                            .map(user-> veeUser))
                .flatMap(user-> veeUserRepository.save((Entreprise) veeUser));
    }

    @Override
    public Mono<? extends VeeUser> passwordChanged(VeeUser veeUser) {
        return Mono.error(new NotImplementedException());
    }

}
