package com.veezen.accountservice.dao;

import com.veezen.accountservice.model.VeeUser;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import org.springframework.stereotype.Repository;


public interface VeeUserRepository<T extends VeeUser, S> extends ReactiveMongoRepository<T, S> {


}
