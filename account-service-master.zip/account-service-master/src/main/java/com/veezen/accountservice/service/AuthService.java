package com.veezen.accountservice.service;

import com.veezen.accountservice.exceptions.NotFoundException;
import com.veezen.accountservice.model.AuthDetail;
import com.veezen.accountservice.model.PasswordChangeModel;
import com.veezen.accountservice.model.UsernamePasswordModel;
import com.veezen.accountservice.model.VeeUser;
import io.fusionauth.domain.User;
import io.fusionauth.domain.api.LoginResponse;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Set;
import java.util.UUID;

@Service
@AllArgsConstructor
public class AuthService {
    private final FusionAuthService fusionAuthService;
    private final AccountServiceFactory accountServiceFactory;



    public Mono<? extends VeeUser> changePassword(PasswordChangeModel passwordChangeModel) {

        return fusionAuthService.login(new UsernamePasswordModel(passwordChangeModel.getUsername(),
                passwordChangeModel.getOldPassword()))
                .switchIfEmpty(Mono.error(new NotFoundException("wrong password")))
                .flatMap(r->
                     fusionAuthService.changePassword(passwordChangeModel)
                ).flatMap(r->
                     fusionAuthService.login(new UsernamePasswordModel(passwordChangeModel.getUsername(),
                            passwordChangeModel.getNewPassword()))
                )
                .flatMap(res-> findUserUsingJwt(res.token))
                .flatMap(this::passwordChanged);
    }

    private  Mono<? extends VeeUser> passwordChanged(VeeUser veeUser) {
        return accountServiceFactory.passwordChanged(veeUser);
    }

    public Mono<? extends  VeeUser> register(VeeUser veeUser)
    {

        return accountServiceFactory.checkUserRegisterAvailabilty(veeUser)
                .filter(Boolean::booleanValue)
                .switchIfEmpty(Mono.error(new IllegalArgumentException("could not register this type of users")))
                .flatMap(v->fusionAuthService.registerUser(veeUser))
                .map(user -> {
                    veeUser.setId(user.id.toString());
                    return veeUser;
                })
                .flatMap(accountServiceFactory::create);
    }


    public Mono<? extends VeeUser> register(AuthDetail authDetail, VeeUser veeUser) {
        return accountServiceFactory.register(authDetail, veeUser);
    }
   
    public Mono<LoginResponse> login(UsernamePasswordModel usernamePasswordModel) {
        return fusionAuthService.login(usernamePasswordModel)
                .switchIfEmpty(Mono.error(new NotFoundException("account   not found")));
    }


    public Mono<ResponseEntity<String>> checkEmail(String email) {
        return fusionAuthService.checkEmail(email);
    }

    public Mono<ResponseEntity<String>> checkUserName(String username) {
        return fusionAuthService.checkUsername(username);
    }

    public Mono< ? extends VeeUser> findUserUsingJwt(String token) {
        return fusionAuthService.getUser(token)
                .flatMap(this::injectVeeUser);
    }

    private Mono< ? extends VeeUser> injectVeeUser(User user) {
        return accountServiceFactory.getOneById(user.id.toString())
                .map(u->{
                    u.setFusionAuthUser(user);
                    return u;
                })
                .switchIfEmpty(Mono.error(new NotFoundException("account   not found")));
    }


}
