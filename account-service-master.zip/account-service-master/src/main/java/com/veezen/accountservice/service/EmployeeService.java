package com.veezen.accountservice.service;

import com.veezen.accountservice.dao.EmployeeRepository;
import com.veezen.accountservice.dao.EntrepriseRepository;
import com.veezen.accountservice.dao.VeeUserRepository;
import com.veezen.accountservice.model.AuthDetail;
import com.veezen.accountservice.model.Employee;
import com.veezen.accountservice.model.Entreprise;
import com.veezen.accountservice.model.VeeUser;
import org.apache.commons.lang3.NotImplementedException;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Set;
import java.util.UUID;

@Service("EmployeeService")
public class EmployeeService extends VeeUserService {
    public final EntrepriseRepository entrepriseRepository;
    public final EmployeeRepository employeeRepository;
    public EmployeeService(EmployeeRepository employeeRepository,
                           EntrepriseRepository entrepriseRepository,
                           FusionAuthService fusionAuthService) {
        super(employeeRepository, fusionAuthService);
        this.entrepriseRepository = entrepriseRepository;
        this.employeeRepository = employeeRepository;
    }

    @Override
    public Mono<? extends VeeUser> create(VeeUser user) {
        return Mono.error(new NotImplementedException());
    }
    @Override
    public Mono<? extends VeeUser> passwordChanged(VeeUser veeUser) {
        return   employeeRepository.findById(veeUser.getId())
                .map(user->{
                    user.setPasswordChangeRequired(false);
                    return user;
                })
                .flatMap(employeeRepository::save);
    }
    @Override
    public Mono<? extends VeeUser> update(VeeUser old, VeeUser user) {
        return null;
    }

    @Override
    public Mono<? extends VeeUser> getOneById(String id) {
        return employeeRepository.findById(id);
    }

    @Override
    boolean canHandle(VeeUser user) {
        return user.getClass().equals(Employee.class);
    }

    @Override
    boolean canHandle(Class<? extends VeeUser> user) {
        return user.equals(Employee.class);
    }

    @Override
    Mono<Boolean> canHandle(String id) {
        return employeeRepository.existsById(id);
    }

    @Override
    public Mono<Boolean> checkOpenRegistration() {
        return Mono.just(false);
    }

    @Override
    public Mono<? extends VeeUser> register(AuthDetail authDetail, VeeUser veeUser) {
        Mono<Entreprise> entreprise  = null;
        System.out.println(authDetail);
       if (authDetail.isContaingRole("Admin"))
        entreprise =  entrepriseRepository.findById(((Employee) veeUser).getEntrepriseId().toString());
       else if (authDetail.isContaingRole("Entreprise_Admin"))
           entreprise = employeeRepository.findById(authDetail.getId().toString())
                   .flatMap(emp-> entrepriseRepository.findById(emp.getEntrepriseId().toString()));
        else
            return Mono.error(NotImplementedException::new);

       return   entreprise
               .filter(ent ->  ent.getCurrentUsersNumber()  + 1 < ent.getMaxNumberOfEmployees())
                .switchIfEmpty(Mono.error(new IllegalArgumentException("contact veezen administrator to increase number of users")))
                .map(ent-> {

                    ent.setCurrentUsersNumber(ent.getCurrentUsersNumber() + 1);
                    return ent;
                })
                .flatMap(ent -> {
                    ((Employee)veeUser).setEntrepriseId(UUID.fromString(ent.getId()));
                 return   registerUser(fusionAuthService, veeUser, employeeRepository)
                         .doOnSuccess(e->
                              entrepriseRepository.save(ent).subscribe()
                         );
                });

    }

    public static Mono<? extends  VeeUser> registerUser(FusionAuthService fusionAuthService,
                                                        VeeUser veeUser,
                                                        EmployeeRepository veeUserRepository)
    {
        return fusionAuthService.registerUserRequireChangePassword(veeUser)
                .map(user->{
                    veeUser.setId(user.id.toString());
                    return (Employee) veeUser;
                })
                .flatMap(veeUserRepository::save);
    }

    public Flux<? extends VeeUser> findAllByEntrepriseId(String id) {
        return employeeRepository.findAllByEntrepriseId(UUID.fromString(id));
    }
}
