package com.veezen.accountservice.controller;

import com.veezen.accountservice.model.AuthDetail;
import com.veezen.accountservice.model.VeeUser;
import com.veezen.accountservice.service.AccountCrudService;
import lombok.AllArgsConstructor;
import org.springframework.lang.Nullable;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Set;
import java.util.UUID;

@RestController
@CrossOrigin("*")
@AllArgsConstructor
public class AccountController {
    private final AccountCrudService accountCrudService;

    @PostMapping("update")
    public Mono<? extends VeeUser> update(Authentication authentication, @RequestBody VeeUser veeUser) {
       var authDetail = (AuthDetail) authentication.getPrincipal();
        return accountCrudService.update(authDetail.getId(), veeUser);
    }

    @GetMapping("/{id}")
    public Mono<? extends VeeUser> getOneById(@PathVariable("id") String id) {
        return accountCrudService.getOneById(id);
    }
    public Mono<? extends VeeUser> fetchAllEntrises()
    {
        return null;
    }

    @GetMapping("fetch/entreprise/users")
    public Flux<? extends  VeeUser> fetchEntrepriseUsers(@Nullable @RequestParam("id") String id ,
                                                         Authentication authentication)
    {
            var authDe  = (AuthDetail) authentication.getPrincipal();
            return  accountCrudService.fetchEntrepriseUsers(id, authDe);
    }
    @PostMapping("/bulk")
    public Flux<? extends VeeUser> getBulkUsers(@RequestBody Set<String> ids) {
        return accountCrudService.getBulkUsers(ids);
    }

    @GetMapping("/all")
    @PreAuthorize("hasRole('Admin')")
    public Flux<? extends VeeUser> getAll() {
        return accountCrudService.getAll();
    }
}
