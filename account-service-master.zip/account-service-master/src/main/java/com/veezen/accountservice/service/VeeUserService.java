package com.veezen.accountservice.service;

import com.veezen.accountservice.dao.VeeUserRepository;
import com.veezen.accountservice.model.AuthDetail;
import com.veezen.accountservice.model.VeeUser;
import lombok.AllArgsConstructor;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Set;

@AllArgsConstructor
public abstract class VeeUserService {
    private final VeeUserRepository<? extends VeeUser, String> veeUserRepository;
    protected final FusionAuthService fusionAuthService;



    public abstract  Mono<? extends  VeeUser> create(VeeUser user);


    public abstract Mono<? extends  VeeUser> update(VeeUser old, VeeUser user);

    public abstract   Mono<? extends  VeeUser> getOneById(String id);

    abstract  boolean canHandle(VeeUser user);
    abstract boolean canHandle(Class<? extends VeeUser> user);
    abstract Mono<Boolean> canHandle(String id);

    public Mono<Void> delete(String id) {
        return veeUserRepository.deleteById(id);
    }

    public Flux<? extends  VeeUser> getAll() {
        return veeUserRepository.findAll();
    }

    public Flux<? extends  VeeUser> getBulkUsers(Set<String> ids)
    {
        return veeUserRepository.findAllById(ids);
    }

    public abstract  Mono<Boolean> checkOpenRegistration() ;

    public abstract Mono<? extends VeeUser> register(AuthDetail authDetail, VeeUser veeUser);

    public abstract  Mono<? extends VeeUser> passwordChanged(VeeUser veeUser);
}
