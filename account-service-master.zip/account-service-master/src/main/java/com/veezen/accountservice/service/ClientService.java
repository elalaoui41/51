package com.veezen.accountservice.service;

import com.veezen.accountservice.dao.ClientRepository;
import com.veezen.accountservice.dao.VeeUserRepository;
import com.veezen.accountservice.model.AuthDetail;
import com.veezen.accountservice.model.Client;
import com.veezen.accountservice.model.VeeUser;
import org.apache.commons.lang3.NotImplementedException;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service("ClientService")
public class ClientService extends VeeUserService {

    private final ClientRepository  veeUserRepository;
    protected ClientService(ClientRepository clientRepository, FusionAuthService fusionAuthService) {
        super(clientRepository,fusionAuthService);
        this.veeUserRepository = clientRepository;
    }

    @Override
    public Mono<? extends VeeUser> create(VeeUser user) {
        return veeUserRepository.save((Client) user);
    }

    @Override
    public Mono<? extends VeeUser> update(VeeUser old, VeeUser user) {
        return Mono.just(old)
                .map(o -> refreshUser((Client) o, (Client) user))
                .flatMap(veeUserRepository::save);
    }

    @Override
    public Mono<? extends VeeUser> getOneById(String id) {
        return veeUserRepository.findById(id);
    }

    private Client refreshUser(Client old, Client user) {
        if (user.getCity() != null)
            old.setCity(user.getCity());
        if (user.getCountry() != null)
            old.setCountry(user.getCountry());
        if (user.getCoverImageUrl() != null)
            old.setCoverImageUrl(user.getCoverImageUrl());
        if (user.getStreet() != null)
            old.setStreet(user.getStreet());
        if (user.getZipCode() != null)
            old.setZipCode(user.getZipCode());
        if (user.getGender() != null)
            old.setGender(user.getGender());
        return old;
    }

    @Override
    boolean canHandle(VeeUser user) {
        return canHandle(user.getClass());
    }

    @Override
    boolean canHandle(Class<? extends VeeUser> user) {
        return user.equals(Client.class);
    }

    @Override
    Mono<Boolean> canHandle(String id) {
        return  veeUserRepository.existsById(id);
    }

    @Override
    public Mono<Boolean> checkOpenRegistration() {
        return Mono.just(true);
    }

    @Override
    public Mono<? extends VeeUser> register(AuthDetail authDetail, VeeUser veeUser) {
        return Mono.error(new NotImplementedException("you should try /auth/register "));
    }

    @Override
    public Mono<? extends VeeUser> passwordChanged(VeeUser veeUser) {
      return   veeUserRepository.findById(veeUser.getId())
                .map(user->{
                    user.setPasswordChangeRequired(false);
                    return user;
                })
                .flatMap(veeUserRepository::save);
    }
}

