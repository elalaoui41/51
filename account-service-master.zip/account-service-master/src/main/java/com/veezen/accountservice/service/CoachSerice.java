package com.veezen.accountservice.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.veezen.accountservice.dao.CoachRepository;
import com.veezen.accountservice.dao.VeeUserRepository;
import com.veezen.accountservice.model.AuthDetail;
import com.veezen.accountservice.model.Coach;
import com.veezen.accountservice.model.VeeUser;
import lombok.AllArgsConstructor;
import org.apache.commons.lang3.NotImplementedException;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Function;

@Service("CoachSerice")
public class CoachSerice extends VeeUserService {
    private final CoachRepository veeUserRepository;

    protected CoachSerice(CoachRepository veeUserRepository, FusionAuthService fusionAuthService) {
        super(veeUserRepository, fusionAuthService);
        this.veeUserRepository = veeUserRepository;
    }

    @Override
    public Mono<? extends VeeUser> register(AuthDetail authDetail, VeeUser veeUser) {
        return Mono.error(new NotImplementedException("try /auth/regsiter"));
    }
    private Coach refreshCoach(Coach old, Coach newOne) {
        if (newOne.getFullName() != null)
            old.setFullName(newOne.getFullName());
        if (newOne.getCity() != null)
            old.setCity(newOne.getCity());
        if (newOne.getCountry() != null)
            old.setCountry(newOne.getCountry());
        if(newOne.getStreet() != null)
            old.setStreet(newOne.getStreet());
        if (newOne.getGender() != null)
            old.setGender(newOne.getGender());
        if (newOne.getCompany() != null)
            old.setCompany(newOne.getCompany());
        if (newOne.getCvUrl() != null)
            old.setCvUrl(newOne.getCvUrl());
        if (newOne.getCoverImageUrl() != null)
            old.setCoverImageUrl(newOne.getCoverImageUrl());
        if (newOne.getExpertise() != null)
            old.setExpertise(newOne.getExpertise());
        if (newOne.getDeplomesAndCertificates() != null)
            old.setDeplomesAndCertificates(newOne.getDeplomesAndCertificates());
        if (newOne.getLanguages() != null)
            old.setLanguages(newOne.getLanguages());
        if (newOne.getConcreteExperience() != null)
            old.setConcreteExperience(newOne.getConcreteExperience());
        if (newOne.getBio() != null)
            old.setBio(newOne.getBio());
        if (newOne.getExperienceDuration() != null)
            old.setExperienceDuration(newOne.getExperienceDuration());
        if(newOne.getAvailablity() != null)
            old.setAvailablity(newOne.getAvailablity());
        if (newOne.getFees() != null)
            old.setFees(newOne.getFees());

        return old;
    }
    @Override
    public Mono<? extends VeeUser> passwordChanged(VeeUser veeUser) {
        return   veeUserRepository.findById(veeUser.getId())
                .map(user->{
                    user.setPasswordChangeRequired(false);
                    return user;
                })
                .flatMap(veeUserRepository::save);
    }
    @Override
    public Mono<? extends VeeUser> create(VeeUser user) {
        return veeUserRepository.save((Coach) user);
    }

    @Override
    public Mono<? extends VeeUser> update(VeeUser old, VeeUser user) {
        return Mono.just(old)
                .map(coach -> refreshCoach((Coach) coach, (Coach) user))
                .flatMap(veeUserRepository::save);
    }

    @Override
    public Mono<? extends VeeUser> getOneById(String id) {
        return veeUserRepository.findById(id);
    }

    @Override
    boolean canHandle(VeeUser user) {
        return canHandle(user.getClass());
    }

    @Override
    boolean canHandle(Class<? extends VeeUser> user) {
        return user.equals(Coach.class);
    }

    @Override
    Mono<Boolean> canHandle(String id) {
        return veeUserRepository.existsById(id);
    }

    @Override
    public Mono<Boolean> checkOpenRegistration() {
        return Mono.just(true);
    }


}
