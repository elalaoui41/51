package com.veezen.accountservice.model;

public enum Availablity {
    PART_TIME, FULL_TIME, CONTRACT, INTERNSHIP, OTHER
}
