package com.veezen.accountservice.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.fusionauth.domain.User;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.lang.Nullable;


import java.util.Set;
import java.util.UUID;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Document(collection = "vee_entreprise")
public class Entreprise extends VeeUser {
    public static final String NAME = "Entreprise";
    @Id
    private String id;
    @Transient
    private String userName;
    @Transient
    private String password;
    private String email;
    private String fullName;
    private PhoneNumber fax;
    private String siteWeb;
    private String ice;
    private String rc;
    private String formeJuridique;
    private Long capital;
    private Set<String> siegeSocialList;
    private String secteur;
    private String city;
    private String country;
    private String street;
    @Transient
    private Employee firstAdmin;
    private PhoneNumber contact;
    private int maxNumberOfEmployees;
    private String avatar;
    private String coverImageUrl;
    private int currentUsersNumber;
    private String zipCode;
    private Gender gender;
    private Long numberOfEmployees;
    private Boolean passwordChangeRequired;


    @JsonCreator
    public Entreprise(@Nullable @JsonProperty("email") String email,
                     @Nullable @JsonProperty("fullName") String fullName,
                     @Nullable @JsonProperty("fax") PhoneNumber fax,
                     @Nullable @JsonProperty("siteWeb") String siteWeb,
                     @Nullable @JsonProperty("ice") String ice,
                     @Nullable @JsonProperty("rc") String rc,
                     @Nullable @JsonProperty("formeJuridique") String formeJuridique,
                     @Nullable @JsonProperty("capital") Long capital,
                     @Nullable @JsonProperty("siegeSocialList") Set<String> siegeSocialList,
                     @Nullable @JsonProperty("secteur") String secteur,
                     @Nullable @JsonProperty("city") String city,
                     @Nullable @JsonProperty("country") String country,
                     @Nullable @JsonProperty("street") String street,
                     @Nullable @JsonProperty("firstAdmin") Employee firstAdmin,
                     @Nullable @JsonProperty("contact") PhoneNumber contact,
                     @Nullable @JsonProperty("maxNumberOfEmployees") int maxNumberOfEmployees,
                     @Nullable @JsonProperty("avatar") String avatar,
                     @Nullable @JsonProperty("numberOfEmployees") Long numberOfEmployees,
                     @Nullable @JsonProperty("coverImageUrl") String coverImageUrl,
                     @Nullable @JsonProperty("zipCode") String zipCode,
                     @Nullable @JsonProperty("gender") Gender gender) {
        this.email = email;
        this.fullName = fullName;
        this.fax = fax;
        this.siteWeb = siteWeb;
        this.numberOfEmployees = numberOfEmployees;
        this.ice = ice;
        this.rc = rc;
        this.formeJuridique = formeJuridique;
        this.capital = capital;
        this.currentUsersNumber = 1;
        this.siegeSocialList = siegeSocialList;
        this.secteur = secteur;
        this.city = city;
        this.country = country;
        this.passwordChangeRequired = false;
        this.street = street;
        var iD = UUID.randomUUID();
        if (firstAdmin!= null) {
            firstAdmin.setEntrepriseId(iD);
            firstAdmin.setRoles(Set.of("Entreprise_Admin"));
        }
        this.firstAdmin = firstAdmin;
        this.id =iD.toString();
        this.contact = contact;
        this.maxNumberOfEmployees = maxNumberOfEmployees;
        this.avatar = avatar;
        this.coverImageUrl = coverImageUrl;
        this.zipCode = zipCode;
        this.gender = gender;
    }

    @Override
    public String getPhoneNumber() {
       return this.contact.getPhoneNumber();
    }

    @Override
    public void setFusionAuthUser(User fusionAuthUser) {

    }

    @Override
    public Set<String> getRoles() {
        return Set.of("Entreprise");
    }

    @Override
    public VeeUser getUser() {
        return firstAdmin;
    }

    public int getCurrentUsersNumber() {
        return currentUsersNumber;
    }

    public void setCurrentUsersNumber(int currentUsersNumber) {
        this.currentUsersNumber = currentUsersNumber;
    }
}
