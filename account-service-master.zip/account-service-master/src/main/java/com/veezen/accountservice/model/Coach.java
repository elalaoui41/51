package com.veezen.accountservice.model;


import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.fusionauth.domain.User;
import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.lang.Nullable;

import java.time.LocalDateTime;
import java.util.Set;
import java.util.UUID;

@AllArgsConstructor
@Document(collection = "vee_coach")
@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class Coach  extends VeeUser {
    public static final String NAME = "Coach";
    @Id
    private String id;
    @Transient
    private String fullName;

    @Transient
    private String email;
    @Transient
    private String password;
    private Gender gender;
    private String phoneNumber;
    private String street;
    private User fusionAuthUser;

    private String city;

    private String country;
    private String company;
    private String cvUrl;
    @Transient
    private String avatar;
    private  Boolean certifiedCoach;
    private String userName;
    private Set<String> expertise;
    private Set<String> deplomesAndCertificates;
    private Set<String> languages;
    private String concreteExperience;
    private String bio;
    private Long experienceDuration;
    private Availablity availablity;
    private String zipCode;

    private String coverImageUrl;
    private Double fees;
    private LocalDateTime createdAt;
    private Boolean passwordChangeRequired;

    public  Set<String> getRoles(){
        return Set.of("Coach");
    }

    @Override
    public VeeUser getUser() {
        return null;
    }

    public Coach(@Nullable @JsonProperty("fullName") String fullName,
                 @Nullable @JsonProperty("email") String email,
                 @Nullable @JsonProperty("password") String password,
                 @Nullable @JsonProperty("gender") Gender gender,
                 @Nullable @JsonProperty("phoneNumber") String phoneNumber,
                 @Nullable @JsonProperty("street") String street,
                 @Nullable @JsonProperty("city") String city,
                 @Nullable @JsonProperty("country") String country,
                 @Nullable @JsonProperty("company") String company,
                 @Nullable @JsonProperty("zipCode") String zipCode,
                 @Nullable @JsonProperty("cvUrl") String cvUrl,
                 @Nullable @JsonProperty("avatar") String avatar,
                 @Nullable @JsonProperty("userName") String userName,
                 @Nullable @JsonProperty("coverImageUrl")  String coverImageUrl,
                 @Nullable @JsonProperty("certifiedCoach") Boolean certifiedCoach,
                 @Nullable @JsonProperty("expertise") Set<String> expertise,
                 @Nullable @JsonProperty("deplomesAndCertificates") Set<String> deplomesAndCertificates,
                 @Nullable @JsonProperty("languages") Set<String> languages,
                 @Nullable @JsonProperty("concreteExperience") String concreteExperience,
                 @Nullable @JsonProperty("bio") String bio,
                 @Nullable @JsonProperty("experienceDuration") Long experienceDuration,
                 @Nullable @JsonProperty("availablity") Availablity availablity,
                 @Nullable @JsonProperty("fees") Double fees) {
        this.fullName = fullName;
        this.email = email;
        this.password = password;
        this.gender = gender;
        this.phoneNumber = phoneNumber;
        this.zipCode = zipCode;
        this.street =   street;
        this.city = city;
        this.country= country;
        this.company = company;
        this.cvUrl = cvUrl;
        this.coverImageUrl = coverImageUrl;
        this.userName = userName;
        this.avatar = avatar;
        this.certifiedCoach = certifiedCoach;
        this.expertise = expertise;
        this.passwordChangeRequired = false;
        this.deplomesAndCertificates = deplomesAndCertificates;
        this.languages = languages;
        this.concreteExperience = concreteExperience;
        this.bio = bio;
        this.experienceDuration = experienceDuration;
        this.availablity = availablity;
        this.fees = fees;
        this.createdAt = LocalDateTime.now();
    }


}
