package com.veezen.accountservice.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.veezen.accountservice.dao.EmployeeRepository;
import io.fusionauth.domain.User;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Set;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.PROPERTY)
@JsonSubTypes({
        @JsonSubTypes.Type(value = Client.class, name = Client.NAME),
        @JsonSubTypes.Type(value = Coach.class, name = Coach.NAME),
        @JsonSubTypes.Type(value = Entreprise.class, name = Entreprise.NAME),
        @JsonSubTypes.Type(value = Employee.class, name = Employee.NAME)
})
public abstract class VeeUser {
  public static final String NAME = "VeeUser";
  abstract public String getId();
  abstract public String getUserName();
  public abstract void setId(String id);
  abstract public String getPassword();
  abstract public String getAvatar();
  abstract public String getEmail();
  abstract public String getFullName();
  abstract public Gender getGender();
  abstract public Boolean getPasswordChangeRequired();
  abstract public void  setPasswordChangeRequired(Boolean value);
  abstract public String getPhoneNumber();
  abstract public void setFusionAuthUser(User fusionAuthUser);

  abstract public String getCity();
  abstract public String getCountry();
  abstract public String getStreet();
  abstract public String getZipCode();
  abstract public String getCoverImageUrl();
  abstract public   Set<String> getRoles();
  abstract public VeeUser getUser();
}
