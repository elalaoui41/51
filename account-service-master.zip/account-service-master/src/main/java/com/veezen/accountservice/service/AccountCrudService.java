package com.veezen.accountservice.service;

import com.veezen.accountservice.exceptions.NotFoundException;
import com.veezen.accountservice.model.AuthDetail;
import com.veezen.accountservice.model.VeeUser;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Set;
import java.util.UUID;

@Service
@AllArgsConstructor
public class AccountCrudService {
    private final FusionAuthService fusionAuthService;
    private final AccountServiceFactory accountServiceFactory;

    public Mono< ? extends VeeUser> update(UUID id, VeeUser veeUser) {
        return fusionAuthService.updateUserByid(id,  veeUser)
                .switchIfEmpty(Mono.error(new NotFoundException("account   not found")))
                .flatMap(u -> accountServiceFactory.getOneById(id.toString()))
                .flatMap(old -> accountServiceFactory.update(old, veeUser));
    }

    public Flux<? extends  VeeUser> getBulkUsers(Set<String> ids)
    {
        return accountServiceFactory.getBulkUsers(ids)
                .flatMap(this::injectFusionAuthUser);
    }
    public Mono<? extends  VeeUser> getOneById(String id)
    {
        return accountServiceFactory.getOneById(id)
                .flatMap(this::injectFusionAuthUser);
    }

    private Mono<? extends VeeUser> injectFusionAuthUser(VeeUser veeUser) {
        return fusionAuthService.getUserById(veeUser.getId())
                .map(user -> {
                    veeUser.setFusionAuthUser(user);
                    return veeUser;
                });
    }

    public Flux<? extends VeeUser> getAll() {
            return accountServiceFactory.getAll()
                    .flatMap(this::injectFusionAuthUser);
    }

    public Flux<? extends VeeUser> fetchEntrepriseUsers(String id, AuthDetail authModel) {
        if (authModel.isContaingRole("Admin"))
            return accountServiceFactory.fetchEntrepriseUsers(id);
        return accountServiceFactory.fetchMyTeam( authModel);
    }
}
