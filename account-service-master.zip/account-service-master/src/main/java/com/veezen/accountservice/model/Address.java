package com.veezen.accountservice.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;

import lombok.RequiredArgsConstructor;


@Data
@RequiredArgsConstructor
public class Address {

    private String street;

    private String city;

    private String country;
    @JsonCreator
    public Address(@JsonProperty("street") String street,
                    @JsonProperty("city") String city,
                    @JsonProperty("country") String country) {
        this.street = street;
        this.city = city;
        this.country = country;
    }
}
