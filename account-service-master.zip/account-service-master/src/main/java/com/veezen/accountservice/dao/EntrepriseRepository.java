package com.veezen.accountservice.dao;

import com.veezen.accountservice.model.Entreprise;

public interface EntrepriseRepository extends VeeUserRepository<Entreprise, String >{
}
