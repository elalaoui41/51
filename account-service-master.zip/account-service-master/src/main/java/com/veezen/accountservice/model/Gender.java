package com.veezen.accountservice.model;

public enum Gender {
    MALE,
    FEMALE,
    OTHER
}
