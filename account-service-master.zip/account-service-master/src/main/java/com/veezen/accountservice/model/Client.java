package com.veezen.accountservice.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.fusionauth.domain.User;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.lang.Nullable;

import java.util.Set;

@Data

@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Document(collection = "vee_client")
public class Client  extends VeeUser {
    public static final String NAME = "Client";
    @Id
    private String id;
    @Transient
    private String userName;
    @Transient
    private String password;
    @Transient
    private String email;
    private String fullName;

    private String phoneNumber;
    private String city;
    private String country;
    private String street;
    private User fusionAuthUser;
    private String zipCode;
    private String coverImageUrl;
    private Boolean passwordChangeRequired;

    @Transient
    private String avatar;
    private Gender gender;

    @JsonCreator
    public Client(@Nullable @JsonProperty("userName") String userName,
                  @Nullable @JsonProperty("password") String password,
                  @Nullable @JsonProperty("email") String email,
                  @Nullable @JsonProperty("fullName") String fullName,
                  @Nullable @JsonProperty("phoneNumber") String phoneNumber,
                  @Nullable @JsonProperty("city") String city,
                  @Nullable @JsonProperty("country") String country,
                  @Nullable @JsonProperty("street") String street,
                  @Nullable @JsonProperty("zipCode") String zipCode,
                  @Nullable @JsonProperty("coverImageUrl") String coverImageUrl,
                  @Nullable @JsonProperty("avatar") String avatar,
                 @Nullable @JsonProperty("gender") Gender gender)
    {
        super();
        this.userName = userName;
        this.password = password;
        this.email = email;
        this.fullName = fullName;
        this.phoneNumber = phoneNumber;
        this.city = city;
        this.country = country;
        this.street = street;
        this.zipCode = zipCode;
        this.passwordChangeRequired =false;
        this.coverImageUrl = coverImageUrl;
        this.avatar = avatar;
        this.gender = gender;
    }
    public  Set<String> getRoles(){
        return Set.of("Client");
    }

    @Override
    public VeeUser getUser() {
        return null;
    }
}
