package com.veezen.accountservice.model;


import com.fasterxml.jackson.annotation.JsonProperty;
import io.fusionauth.domain.User;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.lang.Nullable;

import java.util.Set;
import java.util.UUID;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Document(collection = "vee_employee")
public class Employee extends VeeUser {
    public static final String NAME = "Employee";
    @Id
    private String id;
    private String userName;
    private String password;
    private String email;
    private String fullName;
    private String firstName;
    private String lastName;
    private String phoneNumber;
    private String city;
    private String country;
    private String street;
    private String zipCode;
    private String coverImageUrl;
    private String avatar;
    private UUID entrepriseId;
    private Gender gender;

    private User fusionAuthUser;
    private Set<String> roles;
    private String internalId;
    private String function;
    private Boolean passwordChangeRequired;

    public Employee(@Nullable @JsonProperty("userName") String userName,
                    @Nullable @JsonProperty("passowrd") String password,
                    @Nullable @JsonProperty("email") String email,
                    @Nullable @JsonProperty("firstName") String firstName,
                    @Nullable @JsonProperty("lastName") String lastName,
                    @Nullable @JsonProperty("phoneNumber") String phoneNumber,
                    @Nullable @JsonProperty("city") String city,
                    @Nullable @JsonProperty("country") String country,
                    @Nullable @JsonProperty("street") String street,
                    @Nullable @JsonProperty("zipCode") String zipCode,
                    @Nullable @JsonProperty("coverImageUrl") String coverImageUrl,
                    @Nullable @JsonProperty("avatar") String avatar,
                    @Nullable @JsonProperty("entrepriseId") UUID entrepriseId,
                    @Nullable @JsonProperty("gender") Gender gender,
                    @Nullable @JsonProperty("fusionAuthUser") User fusionAuthUser,
                    @Nullable @JsonProperty("roles") Set<String> roles,
                    @Nullable @JsonProperty("internalId") String internalId,
                    @Nullable @JsonProperty("function") String function) {
        this.userName = userName;
        this.password = password;
        this.email = email;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phoneNumber = phoneNumber;
        this.city = city;
        this.country = country;
        this.street = street;
        this.zipCode = zipCode;
        this.coverImageUrl = coverImageUrl;
        this.avatar = avatar;
        this.entrepriseId = entrepriseId;
        this.gender = gender;
        this.passwordChangeRequired = true;
        this.fusionAuthUser = fusionAuthUser;
        this.roles = roles;
        this.internalId = internalId;
        this.function = function;
    }
    public String getFullName()
    {
        return this.firstName + " " + this.lastName;
    }



    @Override
    public VeeUser getUser() {
        return null;
    }
}
