package com.veezen.accountservice.dao;

import com.veezen.accountservice.model.Employee;
import com.veezen.accountservice.model.VeeUser;
import reactor.core.publisher.Flux;

import java.util.UUID;

public interface EmployeeRepository extends VeeUserRepository<Employee, String> {


    Flux<Employee> findAllByEntrepriseId(UUID id);
}
