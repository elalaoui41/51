package com.veezen.accountservice.dao;

import com.veezen.accountservice.model.Client;
import org.springframework.stereotype.Repository;

@Repository("ClientRepository")
public interface ClientRepository extends VeeUserRepository<Client, String> {


}
