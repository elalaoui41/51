package com.veezen.accountservice.service;

import com.inversoft.error.Errors;
import com.inversoft.rest.ClientResponse;
import com.veezen.accountservice.config.FusionAuthConfig;
import com.veezen.accountservice.exceptions.NotFoundException;
import com.veezen.accountservice.model.PasswordChangeModel;
import com.veezen.accountservice.model.UsernamePasswordModel;
import com.veezen.accountservice.model.VeeUser;
import io.fusionauth.client.FusionAuthClient;
import io.fusionauth.domain.User;
import io.fusionauth.domain.UserRegistration;
import io.fusionauth.domain.api.LoginRequest;
import io.fusionauth.domain.api.LoginResponse;
import io.fusionauth.domain.api.UserRequest;
import io.fusionauth.domain.api.user.ChangePasswordRequest;
import io.fusionauth.domain.api.user.RegistrationRequest;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.net.URI;
import java.util.UUID;


@Service
@AllArgsConstructor
public class FusionAuthService {
    private final FusionAuthClient fusionAuthClient;
    private final FusionAuthConfig fusionAuthConfig;
    public Mono<LoginResponse> login(UsernamePasswordModel user)
    {
        var login  = new LoginRequest()
                        .with(req->req.loginId = user.getUsername())
                        .with(req->req.password = user.getPassword())
                        .with(req->req.applicationId = fusionAuthConfig.appId);

       return  Mono.just(fusionAuthClient.login(login))
               .doOnEach(System.out::println)
               .filter(ClientResponse::wasSuccessful)
               .map(res->res.successResponse);
    }

    public Mono<User> registerUserRequireChangePassword(VeeUser veeUser) {
        UserRegistration userRegistration = new UserRegistration()
                .with(reg->reg.applicationId = fusionAuthConfig.appId)
                .with(reg-> reg.roles.addAll(veeUser.getRoles()));

        var u = new io.fusionauth.domain.User()
                .with(user1 -> user1.email = veeUser.getEmail())
                .with(user1 -> user1.imageUrl = URI.create(veeUser.getAvatar()))
                .with(user1 -> user1.fullName = veeUser.getFullName())
                .with(user1 -> user1.username = veeUser.getUserName())
                .with(user1 -> user1.password = veeUser.getUserName());
                //.with(user1 -> user1.passwordChangeRequired = true);

        return Mono.just(fusionAuthClient.register(null,new RegistrationRequest(u, userRegistration)))
                .flatMap(res->{
                    if (!res.wasSuccessful()) {
                        return Mono.error(new IllegalArgumentException(res.errorResponse.toString()));
                    }
                    return Mono.just(res.successResponse.user);
                });
    }
    public Mono<User> registerUser(VeeUser veeUser) {
        UserRegistration userRegistration = new UserRegistration()
                .with(reg->reg.applicationId = fusionAuthConfig.appId)
                .with(reg-> reg.roles.addAll(veeUser.getRoles()));

        var u = new io.fusionauth.domain.User()
                .with(user1 -> user1.email = veeUser.getEmail())
                .with(user1 -> user1.imageUrl = URI.create(veeUser.getAvatar()))
                .with(user1 -> user1.fullName = veeUser.getFullName())
                .with(user1 -> user1.username = veeUser.getUserName())
                .with(user1 -> user1.password = veeUser.getPassword());

         return Mono.just(fusionAuthClient.register(null,new RegistrationRequest(u, userRegistration)))
                .flatMap(res->{
                    if (!res.wasSuccessful()) {
                        return Mono.error(new IllegalArgumentException(res.errorResponse.toString()));
                    }
                    return Mono.just(res.successResponse.user);
                });
    }

    public Mono<User> getUser(String token) {
        return Mono.just(fusionAuthClient.retrieveUserUsingJWT(token))
                .filter(ClientResponse::wasSuccessful)
                .map(res->res.successResponse.user);
    }
    public Mono<User> updateUserByid(UUID id, VeeUser veeUser) {
        var u = new UserRequest()
                .with(user1 -> {
                            if (veeUser.getAvatar() != null)
                                user1.user.imageUrl = URI.create(veeUser.getAvatar());

                        }
                ) . with(user1 -> {
                            if (veeUser.getFullName() != null)
                                user1.user.fullName = veeUser.getFullName();
                        });
        return Mono.just(fusionAuthClient.updateUser(id, u))
                .filter(ClientResponse::wasSuccessful)
                .map(res->res.successResponse.user);
    }
    public Mono<ResponseEntity<String>> checkEmail(String email)
    {
        return Mono.just(fusionAuthClient.retrieveUserByEmail(email))
                .map(res->{
                   if (res.wasSuccessful())
                       return ResponseEntity.ok("Email is not  available");
                   return ResponseEntity.notFound().build();
                });


    }
    public Mono<ResponseEntity<String>> checkUsername(String userName)
    {
      return   Mono.just(fusionAuthClient.retrieveUserByUsername(userName))
                .map(res->{
                    if (res.wasSuccessful())
                        return ResponseEntity.ok("Email is not  available");
                    return ResponseEntity.notFound().build();
                });
    }

    public Mono<User> getUserById(String id) {
        return Mono.just(fusionAuthClient.retrieveUser(UUID.fromString(id)))
                .filter(ClientResponse::wasSuccessful)
                .map(res->res.successResponse.user);
    }


    public Mono<ClientResponse<Void, Errors>> changePassword(PasswordChangeModel passwordChangeModel) {
        var changePasswordRequest = new ChangePasswordRequest()
                .with(r-> r.applicationId= this.fusionAuthConfig.appId)
                .with(r-> r.loginId = passwordChangeModel.getUsername())
                .with(r-> r.currentPassword = passwordChangeModel.getOldPassword())
                .with(r-> r.password = passwordChangeModel.getNewPassword());

        return Mono.just(fusionAuthClient.changePasswordByIdentity(changePasswordRequest))
                .filter(ClientResponse::wasSuccessful)
                .switchIfEmpty(Mono.error(new NotFoundException("invalid password")));
    }
}
