package com.veezen.accountservice.config;

import io.fusionauth.client.FusionAuthClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.UUID;

@Configuration
public class FusionAuthConfig {


    @Value("${fusionAuth.apiKey}")
    public String apiKey;

    @Value("${fusionAuth.baseUrl}")
    public String baseUrl;
    @Value("${fusionAuth.applicationId}")
    public UUID appId;
    @Value("${fusionAuth.tenantId}")
    public  String tenantId;

    @Bean
    public FusionAuthClient setupClient() {
        return new FusionAuthClient(apiKey, baseUrl,tenantId);
    }
}
