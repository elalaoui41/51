package com.veezen.accountservice.model;

public enum AccountType {
    PHISICAL,
    MORAL
}
