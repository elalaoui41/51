package com.veezen.accountservice.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.lang.Nullable;


@Data
public class UsernamePasswordModel {
    private final String username;
    private final String password;
    public UsernamePasswordModel( @JsonProperty("username") String username,
                                 @JsonProperty("password") String password
                               ) {
        this.username = username;
        this.password = password;
    }
}
