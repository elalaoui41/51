package com.veezen.accountservice.dao;

import com.veezen.accountservice.model.Coach;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.ResponseBody;
import reactor.core.publisher.Mono;

@Repository("CoachRepository")
public interface CoachRepository extends VeeUserRepository<Coach, String> {

}
