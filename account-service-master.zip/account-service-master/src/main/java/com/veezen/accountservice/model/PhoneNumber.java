package com.veezen.accountservice.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PhoneNumber {
    private String countryCode;
    private String areaCode;
    private String number;
    private String phoneNumber;

    public PhoneNumber(@JsonProperty("phoneNumber") String phoneNumber) {
        this.verifyPhoneNumber(phoneNumber);
    }

    private void verifyPhoneNumber(String phoneNumber) {
        if (phoneNumber == null || phoneNumber.isEmpty()) {
            throw new IllegalArgumentException("Phone number is required");
        }
        if (phoneNumber.length() < 10) {
            throw new IllegalArgumentException("Phone number must be at least 10 digits");
        }
        if (phoneNumber.length() > 15) {
            throw new IllegalArgumentException("Phone number must be at most 15 digits");
        }
        // @Todo: validate phone number with regix;
        this.phoneNumber = phoneNumber;
        this.countryCode = phoneNumber.substring(0, 2);
        this.areaCode = phoneNumber.substring(2, 6);
        this.number = phoneNumber.substring(6, phoneNumber.length());
    }
}

