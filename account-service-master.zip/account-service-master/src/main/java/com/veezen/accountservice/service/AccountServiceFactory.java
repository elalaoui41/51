package com.veezen.accountservice.service;

import com.veezen.accountservice.exceptions.NotFoundException;
import com.veezen.accountservice.model.AuthDetail;
import com.veezen.accountservice.model.Employee;
import com.veezen.accountservice.model.VeeUser;
import io.swagger.v3.oas.models.media.Schema;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Set;

@Service
@AllArgsConstructor
public class AccountServiceFactory {
    private final List<VeeUserService> veeUserServices;


    public Mono<? extends VeeUser> create(VeeUser user) {
        return findService(user)
                .create(user);
    }

    public Mono<? extends VeeUser> register(AuthDetail authDetail, VeeUser veeUser) {
        return findService(veeUser)
                .register(authDetail, veeUser);
    }

    public Mono<? extends VeeUser> update(VeeUser old, VeeUser user) {
        return findService(user)
                .update(old, user);
    }

    public Mono<? extends VeeUser> getOneById(String id) {
        System.out.println(id);
        return Flux.fromStream(veeUserServices.stream())
                .filterWhen(eventService -> eventService.canHandle(id))
                .flatMap(eventService -> eventService.getOneById(id))
                .switchIfEmpty(Mono.error(new NotFoundException("account   not found")))
                .next();
    }

    public Flux<? extends VeeUser> getBulkUsers(Set<String> ids) {
        return Flux.fromStream(veeUserServices.stream())
                .flatMap(eventService -> eventService.getBulkUsers(ids));
    }

    public Flux<? extends VeeUser> getAll() {
        return Flux.fromStream(veeUserServices.stream())
                .flatMap(VeeUserService::getAll);
    }

    public Mono<Void> delete(String id) {
        return Flux.fromStream(veeUserServices.stream())
                .filterWhen(eventService -> eventService.canHandle(id))
                .switchIfEmpty(Mono.error(new NotFoundException("Event not found")))
                .flatMap(eventService -> eventService.delete(id))
                .next();
    }

    public VeeUserService findService(VeeUser user) {
        return veeUserServices.stream()
                .filter(service -> service.canHandle(user))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("No service found for user " + user));
    }
    public VeeUserService findService(Class < ? extends VeeUser> user) {
        return veeUserServices.stream()
                .filter(service -> service.canHandle(user))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("No service found for user " + user));
    }

    public Mono<Boolean> checkUserRegisterAvailabilty(VeeUser veeUser) {
        return findService(veeUser)
                .checkOpenRegistration();
    }


    public Mono<? extends VeeUser> passwordChanged(VeeUser veeUser) {
        return findService(veeUser)
                .passwordChanged(veeUser);
    }

    public Flux<? extends VeeUser> fetchEntrepriseUsers(String id) {
        if (id == null)
            return Flux.error(new IllegalArgumentException("id is null"));
    var emplService = findService(Employee.class);
        return ((EmployeeService)emplService).findAllByEntrepriseId(id);
    }

    public Flux<? extends VeeUser> fetchMyTeam( AuthDetail authModel) {
            return findService(Employee.class)
                    .getOneById(authModel.getId().toString())
                    .flatMapMany(u -> fetchEntrepriseUsers(((Employee)u).getEntrepriseId().toString()));
    }
}
