package com.veezen.accountservice.config;

import com.inversoft.error.Errors;
import com.inversoft.rest.ClientResponse;
import com.veezen.accountservice.model.AuthDetail;
import io.fusionauth.client.FusionAuthClient;
import io.fusionauth.domain.api.UserResponse;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.ReactiveAuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.UUID;
import java.util.stream.Collectors;

@Component
public class AuthenticationManager implements ReactiveAuthenticationManager {

    private final UUID appId;
    private  final FusionAuthClient fusionAuthClient;

    public AuthenticationManager(@Value("${fusionAuth.applicationId}") UUID appId, FusionAuthClient fusionAuthClient) {
        //   this.restTemplate = restTemplate;
        this.appId = appId;
        this.fusionAuthClient = fusionAuthClient;
    }

        @Override
        @SuppressWarnings("unchecked")
        public Mono<Authentication> authenticate(Authentication authentication) {
            String token = authentication.getCredentials().toString();


            return Mono.just(retreiveUser(token))
                    .filter(ClientResponse::wasSuccessful)
                    .map(res -> res.successResponse.user)
                    .map(user -> {
                        var roles =   user
                                .getRoleNamesForApplication(appId)
                                .stream()
                                .map(SimpleGrantedAuthority::new)
                                .collect(Collectors.toList());
                        var rolesSet = roles.stream()
                                .map(SimpleGrantedAuthority::getAuthority)
                                .collect(Collectors.toSet());
                        return new UsernamePasswordAuthenticationToken(
                                new AuthDetail(user.id, token, rolesSet ),
                                rolesSet,
                                roles);
                    });
        }

    private ClientResponse<UserResponse, Errors> retreiveUser(String token) {
        return fusionAuthClient.retrieveUserUsingJWT(token);
    }
}