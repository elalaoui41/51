package com.veezen.accountservice.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data

public class PasswordChangeModel {
    private String oldPassword;
    private String username;
    private String newPassword;

    public PasswordChangeModel(@JsonProperty("oldPassword") String oldPassword,
                               @JsonProperty("username") String username,
                               @JsonProperty("newPassword") String newPassword)
    {
        this.username = username;
        this.oldPassword = oldPassword;
        this.newPassword = newPassword;
    }
}
