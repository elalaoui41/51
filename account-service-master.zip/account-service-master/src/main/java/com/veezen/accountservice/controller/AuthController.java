package com.veezen.accountservice.controller;

import com.veezen.accountservice.model.AuthDetail;
import com.veezen.accountservice.model.PasswordChangeModel;
import com.veezen.accountservice.model.UsernamePasswordModel;
import com.veezen.accountservice.model.VeeUser;
import com.veezen.accountservice.service.AuthService;
import com.veezen.accountservice.service.FusionAuthService;
import io.fusionauth.domain.HTTPHeaders;
import io.fusionauth.domain.User;
import io.fusionauth.domain.api.LoginResponse;

import io.netty.handler.codec.http.cookie.Cookie;
import lombok.AllArgsConstructor;
import org.springframework.boot.web.servlet.server.Session;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

@RestController
@AllArgsConstructor
@RequestMapping("/auth")
@CrossOrigin("*")
public class AuthController {
   private final AuthService authService;

   @PostMapping("/register")
    public Mono< ? extends VeeUser> register(@RequestBody VeeUser veeUser) {
       // @todo: add validator when creating admin and Entreprise and employee
       return authService.register(veeUser);
   }
   @PostMapping("/admin/register")
    public Mono< ? extends VeeUser> update(Authentication authentication, @RequestBody VeeUser veeUser) {
            var authDetail = (AuthDetail) authentication.getPrincipal();
            return authService.register(authDetail, veeUser);
   }
    @PostMapping("/login")
    public Mono<ResponseEntity<String>> login(@RequestBody UsernamePasswordModel user){
        return authService.login(user)
                .map(u -> {
            ResponseCookie cookie =  ResponseCookie.from("token", u.token)
                    .maxAge(60 * 60 * 24)
                   .sameSite("None")
                    .path("/")
                    .secure(true)
                    .build();

            return ResponseEntity.ok()
                    .header(HttpHeaders.SET_COOKIE, cookie.toString())
                 //   .header(HttpHeaders.ACCESS_CONTROL_ALLOW_ORIGIN, "dev.veezen.com")
                    .header(HttpHeaders.ACCESS_CONTROL_ALLOW_CREDENTIALS, "true")
                    .body(u.token);
        }) .switchIfEmpty(Mono.just(ResponseEntity.notFound().build()));
    }
    @GetMapping("/check/email")
    public Mono<ResponseEntity<String>> checkEmail(@RequestParam("email") String email){
        return authService.checkEmail(email);
    }
    @GetMapping("/getUserUsingJwt")
    public Mono<? extends VeeUser> getUserUsingJwt(Authentication authentication){
        var authDetail = (AuthDetail) authentication.getPrincipal();
        return authService.findUserUsingJwt(authDetail.getToken());
    }
    @GetMapping("/check/username")
    public Mono<ResponseEntity<String>> checkUserName(@RequestParam("username") String username){
        return authService.checkUserName(username);
    }

    @PostMapping("changePassword")
    public Mono < ?  extends VeeUser> changePassword(@RequestBody
                                                         PasswordChangeModel passwordChangeModel)
    {
        return authService.changePassword(passwordChangeModel);
    }
}
